using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Xunit;

namespace InsuranceAuth.Tests;

public sealed class AuthFlowTests
{
    [Fact]
    public async Task Login_Success_CreatesSessionAndReturnsTokens()
    {
        var user = ActiveUser();
        var users = new FakeUsers(user);
        var sessions = new FakeSessions();
        var auth = CreateAuth(users, sessions, new FakeHasher(passwordValid: true), new FakeAudit());

        var result = await auth.LoginAsync(new LoginRequest("AGENT-10", "SecurePass1"),
            new ClientContext("127.0.0.1", "test", "device"), CancellationToken.None);

        Assert.Equal(user.UserId, result.User.UserId);
        Assert.Equal("access", result.AccessToken);
        Assert.Single(sessions.Created);
        Assert.Equal(0, users.Failures);
    }

    [Fact]
    public async Task Login_WrongPassword_UsesGenericCredentialError()
    {
        var auth = CreateAuth(new FakeUsers(ActiveUser()), new FakeSessions(),
            new FakeHasher(passwordValid: false), new FakeAudit());

        var exception = await Assert.ThrowsAsync<AuthException>(() => auth.LoginAsync(
            new LoginRequest("agent@example.test", "WrongPass1"),
            new ClientContext(null, null, null), CancellationToken.None));

        Assert.Equal("INVALID_CREDENTIALS", exception.ErrorCode);
        Assert.Equal(401, exception.StatusCode);
    }

    [Fact]
    public async Task Login_FourConsecutiveFailures_LocksAccount()
    {
        var users = new FakeUsers(ActiveUser());
        var auth = CreateAuth(users, new FakeSessions(), new FakeHasher(passwordValid: false), new FakeAudit());

        for (var attempt = 1; attempt <= 4; attempt++)
        {
            var exception = await Assert.ThrowsAsync<AuthException>(() => auth.LoginAsync(
                new LoginRequest("AGENT-10", "WrongPass1"),
                new ClientContext(null, null, null), CancellationToken.None));
            Assert.Equal(attempt == 4 ? "ACCOUNT_LOCKED" : "INVALID_CREDENTIALS", exception.ErrorCode);
        }

        Assert.Equal(4, users.Failures);
    }

    [Fact]
    public async Task ResetIdentify_WhenRequestLimitReached_ReturnsRateLimitError()
    {
        var fixture = ResetFixture.Create();
        fixture.Resets.CreateResult = ResultCode.LimitExceeded;
        var exception = await Assert.ThrowsAsync<AuthException>(() => fixture.Service.IdentifyAsync(
            new IdentifyResetRequest("AGENT-10", "dev-captcha", "ABCD"), "127.0.0.1", CancellationToken.None));

        Assert.Equal("RESET_LIMIT_EXCEEDED", exception.ErrorCode);
        Assert.Equal(429, exception.StatusCode);
    }

    [Fact]
    public async Task VerifyOtp_ThirdFailure_EnforcesAttemptLimit()
    {
        var fixture = ResetFixture.Create();
        fixture.Resets.Reset = CreateReset("OtpSent", "otp-ref");
        fixture.Otp.IsValid = false;

        for (var attempt = 1; attempt <= 3; attempt++)
        {
            var exception = await Assert.ThrowsAsync<AuthException>(() => fixture.Service.VerifyOtpAsync(
                new VerifyOtpRequest(fixture.Resets.Reset.ResetId, "123456"), CancellationToken.None));
            Assert.Equal(attempt == 3 ? "OTP_ATTEMPTS_EXCEEDED" : "OTP_INVALID", exception.ErrorCode);
        }

        Assert.Equal(3, fixture.Resets.OtpAttempts);
    }

    [Fact]
    public async Task NewPassword_RejectsPasswordInRecentHistory()
    {
        var fixture = ResetFixture.Create();
        fixture.Resets.TokenReset = CreateReset("Verified", null);
        fixture.Resets.History.Add(new PasswordHistoryEntry("old-hash", DateTime.UtcNow));
        fixture.Hasher.ReusedPassword = "ReusePass1!";

        var exception = await Assert.ThrowsAsync<AuthException>(() => fixture.Service.CompleteAsync(
            new NewPasswordRequest("reset-token", "ReusePass1!"), CancellationToken.None));

        Assert.Equal("PASSWORD_REUSED", exception.ErrorCode);
    }

    [Fact]
    public async Task VerifyOtp_BeforeSendOtp_RejectsOutOfOrderStep()
    {
        var fixture = ResetFixture.Create();
        fixture.Resets.Reset = CreateReset("Identified", null);

        var exception = await Assert.ThrowsAsync<AuthException>(() => fixture.Service.VerifyOtpAsync(
            new VerifyOtpRequest(fixture.Resets.Reset.ResetId, "123456"), CancellationToken.None));

        Assert.Equal("RESET_STEP_INVALID", exception.ErrorCode);
        Assert.Equal(0, fixture.Otp.VerifyCalls);
    }

    [Fact]
    public async Task Argon2idHasher_StoresAndVerifiesEncodedHash()
    {
        var hasher = new InsuranceAuth.Infrastructure.Argon2idPasswordHasher();
        var hash = await hasher.HashAsync("StrongPassword1", CancellationToken.None);

        Assert.StartsWith("$argon2id$v=19$", hash);
        Assert.True(await hasher.VerifyAsync("StrongPassword1", hash, CancellationToken.None));
        Assert.False(await hasher.VerifyAsync("DifferentPassword1", hash, CancellationToken.None));
    }

    [Fact]
    public async Task Registration_CreatesPendingAgentAndSendsBothOtps()
    {
        var fixture = RegistrationFixture.Create();
        var result = await fixture.Service.RegisterAsync(
            new RegisterAgentRequest("New Agent", "9876540021", "New.Agent@example.test",
                null, null, "StrongPassword1!"), CancellationToken.None);

        Assert.Equal("AG00000001", result.AgentCode);
        Assert.True(result.RequiresVerification);
        Assert.Equal("new.agent@example.test", fixture.Repository.Registration.PrimaryEmail);
        Assert.Equal("Pending", fixture.Repository.Registration.Status);
        Assert.Equal(new[] { "PrimaryMobile", "PrimaryEmail" }, fixture.Otp.SentTypes);
    }

    [Fact]
    public async Task Registration_ActivatesOnlyAfterBothOtpsAreVerified()
    {
        var fixture = RegistrationFixture.Create();
        var started = await fixture.Service.RegisterAsync(
            new RegisterAgentRequest("New Agent", "9876540021", "new.agent@example.test",
                null, null, "StrongPassword1!"), CancellationToken.None);

        var result = await fixture.Service.VerifyAsync(
            new VerifyRegistrationRequest(started.RegistrationId, "123456", "654321"),
            CancellationToken.None);

        Assert.True(result.IsActive);
        Assert.Equal("Completed", fixture.Repository.Registration.Status);
        Assert.True(fixture.Repository.Registration.MobileVerified);
        Assert.True(fixture.Repository.Registration.EmailVerified);
        var otpVerifyCalls = fixture.Otp.VerifyCalls;
        var retry = await fixture.Service.VerifyAsync(
            new VerifyRegistrationRequest(started.RegistrationId, "123456", "654321"),
            CancellationToken.None);
        Assert.True(retry.IsActive);
        Assert.Equal(otpVerifyCalls, fixture.Otp.VerifyCalls);
    }

    [Fact]
    public async Task Registration_RejectsPasswordMissingSpecialCharacter()
    {
        var fixture = RegistrationFixture.Create();

        var exception = await Assert.ThrowsAsync<AuthException>(() => fixture.Service.RegisterAsync(
            new RegisterAgentRequest("New Agent", "9876540021", "new.agent@example.test",
                null, null, "StrongPassword1"), CancellationToken.None));

        Assert.Equal("PASSWORD_POLICY_FAILED", exception.ErrorCode);
        Assert.Equal(0, fixture.Repository.CreateCalls);
    }

    private static AuthService CreateAuth(
        FakeUsers users, FakeSessions sessions, FakeHasher hasher, FakeAudit audit)
        => new(users, sessions, audit, hasher, new FakeToken(),
            new LoginRequestValidator(), new AuthOptions());

    private static User ActiveUser()
        => new(Guid.NewGuid(), "AGENT-10", "IRDA-10", "Test Agent", "agent@example.test", null,
            "+919876540021", null, "stored-hash", DateTime.UtcNow, false, "en", "Active", 0, null, null);

    private static ResetRequest CreateReset(string status, string? reference)
        => new(Guid.NewGuid(), Guid.NewGuid(), "PrimaryMobile", reference, status, 0, 0,
            DateTime.UtcNow, null, null, null, null, DateTime.UtcNow, "127.0.0.1");

    private sealed class FakeUsers(User user) : IUserRepository
    {
        public int Failures { get; private set; }
        public Task<User?> GetByLoginIdAsync(string loginId, CancellationToken cancellationToken)
            => Task.FromResult<User?>(user);
        public Task<User?> GetByIdAsync(Guid userId, CancellationToken cancellationToken)
            => Task.FromResult<User?>(userId == user.UserId ? user : null);
        public Task<LoginFailureResult> RegisterFailureAsync(
            Guid userId, int maxAttempts, int lockoutMinutes, CancellationToken cancellationToken)
        {
            Failures++;
            return Task.FromResult(new LoginFailureResult(Failures, Failures >= maxAttempts,
                Failures >= maxAttempts ? DateTime.UtcNow.AddMinutes(lockoutMinutes) : null));
        }
        public Task<ResultCode> RegisterSuccessAsync(Guid userId, CancellationToken cancellationToken) => Task.FromResult(ResultCode.Ok);
    }

    private sealed class FakeSessions : ISessionRepository
    {
        public List<UserSession> Created { get; } = [];
        public Task<ResultCode> CreateAsync(UserSession session, CancellationToken cancellationToken)
        {
            Created.Add(session);
            return Task.FromResult(ResultCode.Ok);
        }
        public Task<ResultCode> RevokeAsync(Guid userId, Guid sessionId, string reason, CancellationToken cancellationToken)
            => Task.FromResult(ResultCode.Ok);
        public Task RevokeAllByUserAsync(Guid userId, string reason, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class FakeAudit : IAuditRepository
    {
        public Task InsertAsync(Guid? userId, string? loginId, string eventType, bool isSuccess,
            string? failureReason, string? ipAddress, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class FakeHasher(bool passwordValid) : IPasswordHasher
    {
        public string? ReusedPassword { get; set; }
        public Task<string> HashAsync(string password, CancellationToken cancellationToken) => Task.FromResult("new-hash");
        public Task<bool> VerifyAsync(string password, string hash, CancellationToken cancellationToken)
            => Task.FromResult(hash == "old-hash" ? password == ReusedPassword : passwordValid);
        public Task BurnTimeAsync(string password, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class FakeToken : ITokenService
    {
        public Task<TokenIssue> IssueAsync(User user, Guid sessionId, CancellationToken cancellationToken)
            => Task.FromResult(new TokenIssue("access", "refresh", DateTime.UtcNow.AddMinutes(15), "token-id"));
    }

    private sealed class FakeResetRepository : IResetRepository
    {
        public ResultCode CreateResult { get; set; } = ResultCode.Ok;
        public ResetRequest Reset { get; set; } = CreateReset("Identified", null);
        public ResetRequest TokenReset { get; set; } = CreateReset("Verified", null);
        public List<PasswordHistoryEntry> History { get; } = [];
        public int OtpAttempts { get; private set; }
        public Task<(Guid? ResetId, ResultCode Result)> CreateAsync(Guid userId, int maxPerHour, string? ipAddress, CancellationToken cancellationToken)
            => Task.FromResult<(Guid?, ResultCode)>((Guid.NewGuid(), CreateResult));
        public Task<ResetRequest?> GetByIdAsync(Guid resetId, CancellationToken cancellationToken)
            => Task.FromResult<ResetRequest?>(Reset.ResetId == resetId ? Reset : null);
        public Task<ResultCode> SetOtpSentAsync(Guid resetId, string destinationType, string? otpReferenceId, int cooldownSeconds, CancellationToken cancellationToken)
            => Task.FromResult(ResultCode.Ok);
        public Task<OtpFailureResult> RegisterOtpFailureAsync(Guid resetId, int maxAttempts, CancellationToken cancellationToken)
        {
            OtpAttempts++;
            return Task.FromResult(new OtpFailureResult(OtpAttempts, OtpAttempts >= maxAttempts));
        }
        public Task<ResultCode> MarkVerifiedAsync(Guid resetId, byte[] tokenHash, DateTime expiresUtc, CancellationToken cancellationToken)
            => Task.FromResult(ResultCode.Ok);
        public Task<ResetRequest?> GetByTokenHashAsync(byte[] tokenHash, CancellationToken cancellationToken)
            => Task.FromResult<ResetRequest?>(TokenReset);
        public Task<IReadOnlyList<PasswordHistoryEntry>> GetLastPasswordsAsync(Guid userId, int count, CancellationToken cancellationToken)
            => Task.FromResult<IReadOnlyList<PasswordHistoryEntry>>(History.Take(count).ToArray());
        public Task<ResultCode> UpdatePasswordAsync(Guid userId, Guid resetId, string passwordHash, CancellationToken cancellationToken)
            => Task.FromResult(ResultCode.Ok);
    }

    private sealed class FakeRegistrationRepository : IRegistrationRepository
    {
        public RegistrationRecord Registration { get; private set; } = new(
            Guid.NewGuid(), Guid.NewGuid(), "AG00000001", "9876540021", "new.agent@example.test",
            null, null, false, false, 0, 0, "Pending", DateTime.UtcNow.AddHours(24), null, null);
        public int CreateCalls { get; private set; }

        public Task<(Guid? RegistrationId, string? AgentCode, ResultCode Result)> CreateAsync(
            string fullName, string primaryMobile, string primaryEmail, string? alternateMobile,
            string? alternateEmail, string passwordHash, int expiresHours, CancellationToken cancellationToken)
        {
            CreateCalls++;
            Registration = Registration with
            {
                PrimaryMobile = primaryMobile,
                PrimaryEmail = primaryEmail,
                ExpiresUtc = DateTime.UtcNow.AddHours(expiresHours)
            };
            return Task.FromResult<(Guid?, string?, ResultCode)>(
                (Registration.RegistrationId, Registration.AgentCode, ResultCode.Ok));
        }

        public Task<RegistrationRecord?> GetAsync(Guid registrationId, CancellationToken cancellationToken)
            => Task.FromResult<RegistrationRecord?>(registrationId == Registration.RegistrationId ? Registration : null);

        public Task<ResultCode> ReserveOtpSendAsync(
            Guid registrationId, string destinationType, int cooldownSeconds, CancellationToken cancellationToken)
            => Task.FromResult(ResultCode.Ok);

        public Task<ResultCode> SaveOtpReferenceAsync(
            Guid registrationId, string destinationType, string otpReferenceId, CancellationToken cancellationToken)
        {
            Registration = destinationType == "PrimaryMobile"
                ? Registration with { MobileOtpReferenceId = otpReferenceId, MobileLastSentUtc = DateTime.UtcNow }
                : Registration with { EmailOtpReferenceId = otpReferenceId, EmailLastSentUtc = DateTime.UtcNow };
            return Task.FromResult(ResultCode.Ok);
        }

        public Task<(ResultCode Result, bool IsComplete)> RecordOtpResultAsync(
            Guid registrationId, string destinationType, bool isValid, int maxAttempts, CancellationToken cancellationToken)
        {
            if (!isValid)
                return Task.FromResult<(ResultCode, bool)>((ResultCode.OtpInvalid, false));
            Registration = destinationType == "PrimaryMobile"
                ? Registration with { MobileVerified = true }
                : Registration with { EmailVerified = true };
            var complete = Registration.MobileVerified && Registration.EmailVerified;
            if (complete)
                Registration = Registration with { Status = "Completed" };
            return Task.FromResult<(ResultCode, bool)>((complete ? ResultCode.Completed : ResultCode.Ok, complete));
        }
    }

    private sealed class FakeCaptcha : ICaptchaClient
    {
        public Task<bool> ValidateAsync(string captchaId, string captchaText, CancellationToken cancellationToken)
            => Task.FromResult(true);
    }

    private sealed class FakeOtp : IOtpClient
    {
        public bool IsValid { get; set; } = true;
        public int VerifyCalls { get; private set; }
        public List<string> SentTypes { get; } = [];
        public Task<string> SendAsync(string destinationType, string destinationValue, string purpose, CancellationToken cancellationToken)
        {
            SentTypes.Add(destinationType);
            return Task.FromResult($"otp-ref-{destinationType}");
        }
        public Task<bool> VerifyAsync(string otpReferenceId, string otp, CancellationToken cancellationToken)
        {
            VerifyCalls++;
            return Task.FromResult(IsValid);
        }
    }

    private sealed class RegistrationFixture
    {
        public required RegistrationService Service { get; init; }
        public required FakeRegistrationRepository Repository { get; init; }
        public required FakeOtp Otp { get; init; }

        public static RegistrationFixture Create()
        {
            var repository = new FakeRegistrationRepository();
            var otp = new FakeOtp();
            var service = new RegistrationService(repository, new FakeHasher(true), otp,
                new RegisterAgentRequestValidator(), new SendRegistrationOtpRequestValidator(),
                new VerifyRegistrationRequestValidator(), new AuthOptions());
            return new RegistrationFixture { Service = service, Repository = repository, Otp = otp };
        }
    }

    private sealed class ResetFixture
    {
        public required PasswordResetService Service { get; init; }
        public required FakeResetRepository Resets { get; init; }
        public required FakeOtp Otp { get; init; }
        public required FakeHasher Hasher { get; init; }

        public static ResetFixture Create()
        {
            var user = ActiveUser();
            var resets = new FakeResetRepository();
            var otp = new FakeOtp();
            var hasher = new FakeHasher(true);
            var service = new PasswordResetService(
                new FakeUsers(user), resets, new FakeAudit(), new FakeCaptcha(), otp, hasher,
                new IdentifyResetRequestValidator(), new SendOtpRequestValidator(),
                new VerifyOtpRequestValidator(), new NewPasswordRequestValidator(), new AuthOptions());
            return new ResetFixture { Service = service, Resets = resets, Otp = otp, Hasher = hasher };
        }
    }
}
