SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO

-- SQL Server only permits CREATE SCHEMA as a standalone batch; the identifier is fixed for safe reruns.
IF SCHEMA_ID(N'auth') IS NULL EXEC(N'CREATE SCHEMA auth');
GO

IF OBJECT_ID(N'auth.UserMaster', N'U') IS NULL
BEGIN
    CREATE TABLE auth.UserMaster
    (
        UserId uniqueidentifier NOT NULL CONSTRAINT PK_UserMaster PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
        AgentCode nvarchar(40) NOT NULL,
        IrdaLicenseNumber nvarchar(60) NULL,
        FullName nvarchar(160) NOT NULL,
        PrimaryEmail nvarchar(254) NOT NULL,
        AlternateEmail nvarchar(254) NULL,
        PrimaryMobile nvarchar(20) NOT NULL,
        AlternateMobile nvarchar(20) NULL,
        PasswordHash nvarchar(512) NOT NULL,
        PasswordChangedUtc datetime2(3) NOT NULL CONSTRAINT DF_UserMaster_PasswordChangedUtc DEFAULT SYSUTCDATETIME(),
        MustChangePassword bit NOT NULL CONSTRAINT DF_UserMaster_MustChangePassword DEFAULT 0,
        PreferredLanguage nvarchar(12) NOT NULL CONSTRAINT DF_UserMaster_PreferredLanguage DEFAULT N'en',
        Status varchar(10) NOT NULL CONSTRAINT DF_UserMaster_Status DEFAULT 'Active',
        FailedLoginCount int NOT NULL CONSTRAINT DF_UserMaster_FailedLoginCount DEFAULT 0,
        LockoutEndUtc datetime2(3) NULL,
        LastLoginUtc datetime2(3) NULL,
        IsDeleted bit NOT NULL CONSTRAINT DF_UserMaster_IsDeleted DEFAULT 0,
        CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_UserMaster_CreatedUtc DEFAULT SYSUTCDATETIME(),
        UpdatedUtc datetime2(3) NOT NULL CONSTRAINT DF_UserMaster_UpdatedUtc DEFAULT SYSUTCDATETIME(),
        RowVersion rowversion NOT NULL,
        AgentCodeNormalized AS UPPER(AgentCode) PERSISTED,
        PrimaryEmailNormalized AS UPPER(PrimaryEmail) PERSISTED,
        IrdaLicenseNumberNormalized AS UPPER(IrdaLicenseNumber) PERSISTED,
        CONSTRAINT UQ_UserMaster_AgentCode UNIQUE (AgentCode),
        CONSTRAINT UQ_UserMaster_PrimaryEmail UNIQUE (PrimaryEmail),
        CONSTRAINT CK_UserMaster_Status CHECK (Status IN ('Active', 'Locked', 'Inactive')),
        CONSTRAINT CK_UserMaster_FailedLoginCount CHECK (FailedLoginCount >= 0)
    );
END;
GO

IF OBJECT_ID(N'auth.PasswordHistory', N'U') IS NULL
BEGIN
    CREATE TABLE auth.PasswordHistory
    (
        HistoryId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_PasswordHistory PRIMARY KEY,
        UserId uniqueidentifier NOT NULL,
        PasswordHash nvarchar(512) NOT NULL,
        CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_PasswordHistory_CreatedUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_PasswordHistory_UserMaster FOREIGN KEY (UserId) REFERENCES auth.UserMaster(UserId)
    );
END;
GO

IF OBJECT_ID(N'auth.PasswordResetRequest', N'U') IS NULL
BEGIN
    CREATE TABLE auth.PasswordResetRequest
    (
        ResetId uniqueidentifier NOT NULL CONSTRAINT PK_PasswordResetRequest PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
        UserId uniqueidentifier NOT NULL,
        DestinationType varchar(20) NULL,
        OtpReferenceId nvarchar(200) NULL,
        Status varchar(12) NOT NULL CONSTRAINT DF_PasswordResetRequest_Status DEFAULT 'Identified',
        OtpAttemptCount int NOT NULL CONSTRAINT DF_PasswordResetRequest_OtpAttemptCount DEFAULT 0,
        ResendCount int NOT NULL CONSTRAINT DF_PasswordResetRequest_ResendCount DEFAULT 0,
        LastSentUtc datetime2(3) NULL,
        VerifiedUtc datetime2(3) NULL,
        ResetTokenHash varbinary(32) NULL,
        ResetTokenExpiresUtc datetime2(3) NULL,
        UsedUtc datetime2(3) NULL,
        RequestedUtc datetime2(3) NOT NULL CONSTRAINT DF_PasswordResetRequest_RequestedUtc DEFAULT SYSUTCDATETIME(),
        IpAddress varchar(45) NULL,
        CONSTRAINT FK_PasswordResetRequest_UserMaster FOREIGN KEY (UserId) REFERENCES auth.UserMaster(UserId),
        CONSTRAINT CK_PasswordResetRequest_DestinationType CHECK (DestinationType IS NULL OR DestinationType IN ('PrimaryMobile', 'PrimaryEmail', 'AlternateMobile', 'AlternateEmail')),
        CONSTRAINT CK_PasswordResetRequest_Status CHECK (Status IN ('Identified', 'OtpSent', 'Verified', 'Completed', 'Expired', 'Failed')),
        CONSTRAINT CK_PasswordResetRequest_Attempts CHECK (OtpAttemptCount >= 0 AND ResendCount >= 0)
    );
END;
GO

IF OBJECT_ID(N'auth.UserSession', N'U') IS NULL
BEGIN
    CREATE TABLE auth.UserSession
    (
        SessionId uniqueidentifier NOT NULL CONSTRAINT PK_UserSession PRIMARY KEY,
        UserId uniqueidentifier NOT NULL,
        TokenId nvarchar(200) NOT NULL,
        IpAddress varchar(45) NULL,
        UserAgent nvarchar(512) NULL,
        DeviceInfo nvarchar(256) NULL,
        CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_UserSession_CreatedUtc DEFAULT SYSUTCDATETIME(),
        ExpiresUtc datetime2(3) NOT NULL,
        LastActivityUtc datetime2(3) NOT NULL CONSTRAINT DF_UserSession_LastActivityUtc DEFAULT SYSUTCDATETIME(),
        RevokedUtc datetime2(3) NULL,
        RevokedReason nvarchar(100) NULL,
        CONSTRAINT FK_UserSession_UserMaster FOREIGN KEY (UserId) REFERENCES auth.UserMaster(UserId)
    );
END;
GO

IF OBJECT_ID(N'auth.LoginAudit', N'U') IS NULL
BEGIN
    CREATE TABLE auth.LoginAudit
    (
        AuditId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_LoginAudit PRIMARY KEY,
        UserId uniqueidentifier NULL,
        LoginIdEntered nvarchar(254) NULL,
        EventType varchar(20) NOT NULL,
        IsSuccess bit NOT NULL,
        FailureReason nvarchar(100) NULL,
        IpAddress varchar(45) NULL,
        CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_LoginAudit_CreatedUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_LoginAudit_UserMaster FOREIGN KEY (UserId) REFERENCES auth.UserMaster(UserId),
        CONSTRAINT CK_LoginAudit_EventType CHECK (EventType IN ('LoginSuccess', 'LoginFailed', 'Locked', 'OtpSent', 'OtpVerified', 'PasswordReset'))
    );
END;
GO

IF OBJECT_ID(N'auth.ApplicationSetting', N'U') IS NULL
BEGIN
    CREATE TABLE auth.ApplicationSetting
    (
        SettingKey nvarchar(100) NOT NULL CONSTRAINT PK_ApplicationSetting PRIMARY KEY,
        SettingValue nvarchar(400) NOT NULL,
        UpdatedUtc datetime2(3) NOT NULL CONSTRAINT DF_ApplicationSetting_UpdatedUtc DEFAULT SYSUTCDATETIME()
    );
END;
GO
