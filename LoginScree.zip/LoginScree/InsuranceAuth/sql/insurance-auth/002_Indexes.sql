SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.UserMaster') AND name = N'UX_UserMaster_AgentCodeNormalized')
    CREATE UNIQUE INDEX UX_UserMaster_AgentCodeNormalized ON auth.UserMaster(AgentCodeNormalized) INCLUDE (UserId, IsDeleted);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.UserMaster') AND name = N'UX_UserMaster_PrimaryEmailNormalized')
    CREATE UNIQUE INDEX UX_UserMaster_PrimaryEmailNormalized ON auth.UserMaster(PrimaryEmailNormalized) INCLUDE (UserId, IsDeleted);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.UserMaster') AND name = N'UX_UserMaster_IrdaLicenseNumberNormalized')
    CREATE UNIQUE INDEX UX_UserMaster_IrdaLicenseNumberNormalized ON auth.UserMaster(IrdaLicenseNumberNormalized) WHERE IrdaLicenseNumber IS NOT NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.PasswordHistory') AND name = N'IX_PasswordHistory_UserId_CreatedUtc')
    CREATE INDEX IX_PasswordHistory_UserId_CreatedUtc ON auth.PasswordHistory(UserId, CreatedUtc DESC) INCLUDE (PasswordHash);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.PasswordResetRequest') AND name = N'IX_PasswordResetRequest_UserId_RequestedUtc')
    CREATE INDEX IX_PasswordResetRequest_UserId_RequestedUtc ON auth.PasswordResetRequest(UserId, RequestedUtc DESC) INCLUDE (Status);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.PasswordResetRequest') AND name = N'UX_PasswordResetRequest_ResetTokenHash')
    CREATE UNIQUE INDEX UX_PasswordResetRequest_ResetTokenHash ON auth.PasswordResetRequest(ResetTokenHash) WHERE ResetTokenHash IS NOT NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.UserSession') AND name = N'IX_UserSession_UserId_Active')
    CREATE INDEX IX_UserSession_UserId_Active ON auth.UserSession(UserId, RevokedUtc, ExpiresUtc);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.UserSession') AND name = N'UX_UserSession_TokenId')
    CREATE UNIQUE INDEX UX_UserSession_TokenId ON auth.UserSession(TokenId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.LoginAudit') AND name = N'IX_LoginAudit_UserId_CreatedUtc')
    CREATE INDEX IX_LoginAudit_UserId_CreatedUtc ON auth.LoginAudit(UserId, CreatedUtc DESC);
GO
