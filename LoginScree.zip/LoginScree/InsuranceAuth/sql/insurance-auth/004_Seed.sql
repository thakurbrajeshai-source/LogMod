SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

MERGE auth.ApplicationSetting AS target
USING (VALUES
    (N'PasswordHistoryCount', N'5'),
    (N'ResetRequestsPerHour', N'3'),
    (N'ResetOtpMaxAttempts', N'3'),
    (N'ResetOtpCooldownSeconds', N'30'),
    (N'ResetTokenMinutes', N'10'),
    (N'LoginMaxFailedAttempts', N'4'),
    (N'LoginLockoutMinutes', N'15')
) AS source(SettingKey, SettingValue)
ON target.SettingKey = source.SettingKey
WHEN NOT MATCHED THEN
    INSERT (SettingKey, SettingValue) VALUES (source.SettingKey, source.SettingValue);
GO
