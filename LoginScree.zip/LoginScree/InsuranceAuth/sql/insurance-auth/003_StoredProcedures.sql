SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE auth.usp_User_GetByLoginId
    @LoginId nvarchar(254),
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    SELECT TOP (1)
        UserId, AgentCode, IrdaLicenseNumber, FullName, PrimaryEmail, AlternateEmail,
        PrimaryMobile, AlternateMobile, PasswordHash, PasswordChangedUtc, MustChangePassword,
        PreferredLanguage, Status, FailedLoginCount, LockoutEndUtc, LastLoginUtc, IsDeleted
    FROM auth.UserMaster
    WHERE IsDeleted = 0 AND
        (AgentCodeNormalized = UPPER(@LoginId) OR PrimaryEmailNormalized = UPPER(@LoginId)
         OR IrdaLicenseNumberNormalized = UPPER(@LoginId))
    ORDER BY CASE WHEN AgentCodeNormalized = UPPER(@LoginId) THEN 1
                  WHEN PrimaryEmailNormalized = UPPER(@LoginId) THEN 2 ELSE 3 END;
    SET @ResultCode = IIF(@@ROWCOUNT = 0, 'NOT_FOUND', 'OK');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_User_GetById
    @UserId uniqueidentifier,
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    SELECT
        UserId, AgentCode, IrdaLicenseNumber, FullName, PrimaryEmail, AlternateEmail,
        PrimaryMobile, AlternateMobile, PasswordHash, PasswordChangedUtc, MustChangePassword,
        PreferredLanguage, Status, FailedLoginCount, LockoutEndUtc, LastLoginUtc, IsDeleted
    FROM auth.UserMaster WHERE UserId = @UserId AND IsDeleted = 0;
    SET @ResultCode = IIF(@@ROWCOUNT = 0, 'NOT_FOUND', 'OK');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Login_RegisterFailure
    @UserId uniqueidentifier,
    @MaxAttempts int,
    @LockoutMinutes int,
    @FailedLoginCount int OUTPUT,
    @IsLocked bit OUTPUT,
    @LockoutEndUtc datetime2(3) OUTPUT,
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        SET @FailedLoginCount = 0;
        SET @IsLocked = 0;
        SET @LockoutEndUtc = NULL;
        DECLARE @Now datetime2(3) = SYSUTCDATETIME(), @CurrentStatus varchar(10);
        SELECT @FailedLoginCount = FailedLoginCount, @LockoutEndUtc = LockoutEndUtc, @CurrentStatus = Status
        FROM auth.UserMaster WITH (UPDLOCK, ROWLOCK)
        WHERE UserId = @UserId AND IsDeleted = 0;
        IF @CurrentStatus IS NULL
        BEGIN
            SET @ResultCode = 'NOT_FOUND';
            SET @IsLocked = 0;
            COMMIT;
            RETURN;
        END;
        IF @CurrentStatus = 'Inactive'
        BEGIN
            SET @ResultCode = 'INACTIVE';
            SET @IsLocked = 0;
            COMMIT;
            RETURN;
        END;
        IF @CurrentStatus = 'Locked' AND @LockoutEndUtc > @Now
        BEGIN
            SET @IsLocked = 1;
            SET @ResultCode = 'LOCKED';
            COMMIT;
            RETURN;
        END;
        UPDATE auth.UserMaster
        SET FailedLoginCount = CASE WHEN @LockoutEndUtc IS NOT NULL AND @LockoutEndUtc <= @Now THEN 1 ELSE FailedLoginCount + 1 END,
            Status = CASE WHEN (CASE WHEN @LockoutEndUtc IS NOT NULL AND @LockoutEndUtc <= @Now THEN 1 ELSE FailedLoginCount + 1 END) >= @MaxAttempts THEN 'Locked' ELSE 'Active' END,
            LockoutEndUtc = CASE WHEN (CASE WHEN @LockoutEndUtc IS NOT NULL AND @LockoutEndUtc <= @Now THEN 1 ELSE FailedLoginCount + 1 END) >= @MaxAttempts THEN DATEADD(MINUTE, @LockoutMinutes, @Now) ELSE NULL END,
            UpdatedUtc = @Now
        WHERE UserId = @UserId;
        SELECT @FailedLoginCount = FailedLoginCount, @LockoutEndUtc = LockoutEndUtc, @CurrentStatus = Status
        FROM auth.UserMaster WHERE UserId = @UserId;
        SET @IsLocked = IIF(@CurrentStatus = 'Locked', 1, 0);
        SET @ResultCode = IIF(@IsLocked = 1, 'LOCKED', 'OK');
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Login_RegisterSuccess
    @UserId uniqueidentifier,
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    UPDATE auth.UserMaster WITH (ROWLOCK)
    SET FailedLoginCount = 0, Status = 'Active', LockoutEndUtc = NULL,
        LastLoginUtc = SYSUTCDATETIME(), UpdatedUtc = SYSUTCDATETIME()
    WHERE UserId = @UserId AND IsDeleted = 0 AND Status <> 'Inactive'
      AND (LockoutEndUtc IS NULL OR LockoutEndUtc <= SYSUTCDATETIME());
    IF @@ROWCOUNT = 1 SET @ResultCode = 'OK';
    ELSE IF EXISTS (SELECT 1 FROM auth.UserMaster WHERE UserId = @UserId AND IsDeleted = 0 AND Status = 'Inactive')
        SET @ResultCode = 'INACTIVE';
    ELSE SET @ResultCode = 'LOCKED';
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Session_Create
    @SessionId uniqueidentifier, @UserId uniqueidentifier, @TokenId nvarchar(200),
    @IpAddress varchar(45), @UserAgent nvarchar(512), @DeviceInfo nvarchar(256),
    @ExpiresUtc datetime2(3), @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM auth.UserMaster WITH (UPDLOCK, HOLDLOCK)
            WHERE UserId = @UserId AND IsDeleted = 0 AND Status = 'Active')
        BEGIN SET @ResultCode = 'INACTIVE'; COMMIT; RETURN; END;
        INSERT auth.UserSession(SessionId, UserId, TokenId, IpAddress, UserAgent, DeviceInfo, ExpiresUtc)
        VALUES (@SessionId, @UserId, @TokenId, @IpAddress, @UserAgent, @DeviceInfo, @ExpiresUtc);
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Session_Revoke
    @SessionId uniqueidentifier, @UserId uniqueidentifier, @Reason nvarchar(100),
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    UPDATE auth.UserSession SET RevokedUtc = SYSUTCDATETIME(), RevokedReason = @Reason
    WHERE SessionId = @SessionId AND UserId = @UserId AND RevokedUtc IS NULL;
    SET @ResultCode = IIF(@@ROWCOUNT = 1, 'OK', 'NOT_FOUND');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Session_RevokeAllByUser
    @UserId uniqueidentifier, @Reason nvarchar(100), @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    UPDATE auth.UserSession SET RevokedUtc = SYSUTCDATETIME(), RevokedReason = @Reason
    WHERE UserId = @UserId AND RevokedUtc IS NULL;
    SET @ResultCode = 'OK';
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_Create
    @UserId uniqueidentifier, @MaxPerHour int, @IpAddress varchar(45),
    @ResetId uniqueidentifier OUTPUT, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM auth.UserMaster WITH (UPDLOCK, HOLDLOCK) WHERE UserId = @UserId AND IsDeleted = 0 AND Status = 'Active')
        BEGIN SET @ResultCode = 'NOT_FOUND'; COMMIT; RETURN; END;
        IF (SELECT COUNT_BIG(*) FROM auth.PasswordResetRequest WITH (UPDLOCK, HOLDLOCK)
            WHERE UserId = @UserId AND RequestedUtc >= DATEADD(HOUR, -1, SYSUTCDATETIME())) >= @MaxPerHour
        BEGIN SET @ResultCode = 'LIMIT_EXCEEDED'; COMMIT; RETURN; END;
        SET @ResetId = NEWID();
        INSERT auth.PasswordResetRequest(ResetId, UserId, IpAddress)
        VALUES (@ResetId, @UserId, @IpAddress);
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_GetById
    @ResetId uniqueidentifier, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    SELECT ResetId, UserId, DestinationType, OtpReferenceId, Status,
        OtpAttemptCount, ResendCount, LastSentUtc, VerifiedUtc, ResetTokenHash,
        ResetTokenExpiresUtc, UsedUtc, RequestedUtc, IpAddress
    FROM auth.PasswordResetRequest WHERE ResetId = @ResetId;
    SET @ResultCode = IIF(@@ROWCOUNT = 0, 'NOT_FOUND', 'OK');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_SetOtpSent
    @ResetId uniqueidentifier, @DestinationType varchar(20), @OtpReferenceId nvarchar(200) = NULL,
    @ResendCooldownSeconds int, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @Status varchar(12), @LastSent datetime2(3), @ExistingReference nvarchar(200);
        SELECT @Status = Status, @LastSent = LastSentUtc, @ExistingReference = OtpReferenceId
        FROM auth.PasswordResetRequest WITH (UPDLOCK, ROWLOCK) WHERE ResetId = @ResetId;
        IF @Status IS NULL OR @Status NOT IN ('Identified', 'OtpSent')
        BEGIN SET @ResultCode = 'INVALID_STATE'; COMMIT; RETURN; END;
        IF @LastSent IS NOT NULL AND DATEDIFF(SECOND, @LastSent, SYSUTCDATETIME()) < @ResendCooldownSeconds
        BEGIN
            IF @OtpReferenceId IS NOT NULL AND @ExistingReference IS NULL
            BEGIN
                UPDATE auth.PasswordResetRequest
                SET OtpReferenceId = @OtpReferenceId, DestinationType = @DestinationType, Status = 'OtpSent'
                WHERE ResetId = @ResetId AND OtpReferenceId IS NULL;
                SET @ResultCode = IIF(@@ROWCOUNT = 1, 'OK', 'COOLDOWN');
            END
            ELSE SET @ResultCode = 'COOLDOWN';
            COMMIT;
            RETURN;
        END;
        UPDATE auth.PasswordResetRequest
        SET DestinationType = @DestinationType, OtpReferenceId = @OtpReferenceId,
            Status = IIF(@OtpReferenceId IS NULL, Status, 'OtpSent'),
            LastSentUtc = SYSUTCDATETIME(),
            ResendCount = ResendCount + IIF(LastSentUtc IS NULL, 0, 1)
        WHERE ResetId = @ResetId;
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_RegisterOtpFailure
    @ResetId uniqueidentifier, @MaxAttempts int, @OtpAttemptCount int OUTPUT,
    @IsFailed bit OUTPUT, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        UPDATE auth.PasswordResetRequest WITH (UPDLOCK, ROWLOCK)
        SET OtpAttemptCount = OtpAttemptCount + 1,
            Status = IIF(OtpAttemptCount + 1 >= @MaxAttempts, 'Failed', Status)
        WHERE ResetId = @ResetId AND Status = 'OtpSent';
        IF @@ROWCOUNT = 0
        BEGIN SET @ResultCode = 'INVALID_STATE'; SET @IsFailed = 0; COMMIT; RETURN; END;
        SELECT @OtpAttemptCount = OtpAttemptCount, @IsFailed = IIF(Status = 'Failed', 1, 0)
        FROM auth.PasswordResetRequest WHERE ResetId = @ResetId;
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_MarkVerified
    @ResetId uniqueidentifier, @ResetTokenHash varbinary(32), @TokenExpiresUtc datetime2(3),
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    UPDATE auth.PasswordResetRequest
    SET Status = 'Verified', VerifiedUtc = SYSUTCDATETIME(),
        ResetTokenHash = @ResetTokenHash, ResetTokenExpiresUtc = @TokenExpiresUtc
    WHERE ResetId = @ResetId AND Status = 'OtpSent';
    SET @ResultCode = IIF(@@ROWCOUNT = 1, 'OK', 'INVALID_STATE');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Reset_GetByTokenHash
    @ResetTokenHash varbinary(32), @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    SELECT ResetId, UserId, DestinationType, OtpReferenceId, Status,
        OtpAttemptCount, ResendCount, LastSentUtc, VerifiedUtc, ResetTokenHash,
        ResetTokenExpiresUtc, UsedUtc, RequestedUtc, IpAddress
    FROM auth.PasswordResetRequest
    WHERE ResetTokenHash = @ResetTokenHash AND Status = 'Verified'
      AND ResetTokenExpiresUtc > SYSUTCDATETIME() AND UsedUtc IS NULL;
    SET @ResultCode = IIF(@@ROWCOUNT = 0, 'NOT_FOUND', 'OK');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_PasswordHistory_GetLast
    @UserId uniqueidentifier, @Count int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    SELECT TOP (@Count) PasswordHash, CreatedUtc
    FROM auth.PasswordHistory WHERE UserId = @UserId ORDER BY CreatedUtc DESC, HistoryId DESC;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Password_Update
    @UserId uniqueidentifier, @ResetId uniqueidentifier, @PasswordHash nvarchar(512),
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @CurrentPasswordHash nvarchar(512);
        IF NOT EXISTS (SELECT 1 FROM auth.PasswordResetRequest WITH (UPDLOCK, ROWLOCK)
            WHERE ResetId = @ResetId AND UserId = @UserId AND Status = 'Verified'
              AND ResetTokenExpiresUtc > SYSUTCDATETIME() AND UsedUtc IS NULL)
        BEGIN SET @ResultCode = 'INVALID_TOKEN'; COMMIT; RETURN; END;
        SELECT @CurrentPasswordHash = PasswordHash
        FROM auth.UserMaster WITH (UPDLOCK, ROWLOCK)
        WHERE UserId = @UserId AND IsDeleted = 0;
        IF @CurrentPasswordHash IS NULL
        BEGIN SET @ResultCode = 'NOT_FOUND'; ROLLBACK; RETURN; END;
        IF NOT EXISTS (SELECT 1 FROM auth.PasswordHistory
            WHERE UserId = @UserId AND PasswordHash = @CurrentPasswordHash)
            INSERT auth.PasswordHistory(UserId, PasswordHash) VALUES (@UserId, @CurrentPasswordHash);
        UPDATE auth.UserMaster WITH (UPDLOCK, ROWLOCK)
        SET PasswordHash = @PasswordHash, PasswordChangedUtc = SYSUTCDATETIME(),
            MustChangePassword = 0, FailedLoginCount = 0, LockoutEndUtc = NULL,
            Status = 'Active', UpdatedUtc = SYSUTCDATETIME()
        WHERE UserId = @UserId AND IsDeleted = 0;
        IF @@ROWCOUNT = 0
        BEGIN SET @ResultCode = 'NOT_FOUND'; ROLLBACK; RETURN; END;
        INSERT auth.PasswordHistory(UserId, PasswordHash) VALUES (@UserId, @PasswordHash);
        DELETE FROM auth.PasswordHistory
        WHERE UserId = @UserId AND HistoryId NOT IN
            (SELECT TOP (5) HistoryId FROM auth.PasswordHistory WHERE UserId = @UserId ORDER BY CreatedUtc DESC, HistoryId DESC);
        UPDATE auth.UserSession SET RevokedUtc = SYSUTCDATETIME(), RevokedReason = N'PasswordReset'
        WHERE UserId = @UserId AND RevokedUtc IS NULL;
        UPDATE auth.PasswordResetRequest SET Status = 'Completed', UsedUtc = SYSUTCDATETIME()
        WHERE ResetId = @ResetId;
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Audit_Insert
    @UserId uniqueidentifier = NULL, @LoginIdEntered nvarchar(254) = NULL,
    @EventType varchar(20), @IsSuccess bit, @FailureReason nvarchar(100) = NULL,
    @IpAddress varchar(45) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
    INSERT auth.LoginAudit(UserId, LoginIdEntered, EventType, IsSuccess, FailureReason, IpAddress)
    VALUES (@UserId, @LoginIdEntered, @EventType, @IsSuccess, @FailureReason, @IpAddress);
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_DevSeed_UserUpsert
    @AgentCode nvarchar(40), @IrdaLicenseNumber nvarchar(60), @FullName nvarchar(160),
    @PrimaryEmail nvarchar(254), @AlternateEmail nvarchar(254), @PrimaryMobile nvarchar(20),
    @AlternateMobile nvarchar(20), @PasswordHash nvarchar(512),
    @UserId uniqueidentifier OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @UserId = UserId FROM auth.UserMaster WITH (UPDLOCK, SERIALIZABLE)
        WHERE AgentCodeNormalized = UPPER(@AgentCode);
        IF @UserId IS NULL
        BEGIN
            SET @UserId = NEWID();
            INSERT auth.UserMaster(UserId, AgentCode, IrdaLicenseNumber, FullName, PrimaryEmail,
                AlternateEmail, PrimaryMobile, AlternateMobile, PasswordHash)
            VALUES (@UserId, @AgentCode, @IrdaLicenseNumber, @FullName, @PrimaryEmail,
                @AlternateEmail, @PrimaryMobile, @AlternateMobile, @PasswordHash);
            INSERT auth.PasswordHistory(UserId, PasswordHash) VALUES (@UserId, @PasswordHash);
        END
        ELSE
            UPDATE auth.UserMaster SET IrdaLicenseNumber = @IrdaLicenseNumber, FullName = @FullName,
                PrimaryEmail = @PrimaryEmail, AlternateEmail = @AlternateEmail, PrimaryMobile = @PrimaryMobile,
                AlternateMobile = @AlternateMobile, PasswordHash = @PasswordHash,
                Status = 'Active', IsDeleted = 0, UpdatedUtc = SYSUTCDATETIME()
            WHERE UserId = @UserId;
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO
