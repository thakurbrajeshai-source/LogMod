SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO

IF OBJECT_ID(N'auth.AgentCodeSequence', N'SO') IS NULL
    CREATE SEQUENCE auth.AgentCodeSequence AS bigint START WITH 1 INCREMENT BY 1;
GO

IF OBJECT_ID(N'auth.AgentRegistration', N'U') IS NULL
BEGIN
    CREATE TABLE auth.AgentRegistration
    (
        RegistrationId uniqueidentifier NOT NULL CONSTRAINT PK_AgentRegistration PRIMARY KEY,
        UserId uniqueidentifier NOT NULL,
        MobileOtpReferenceId nvarchar(200) NULL,
        EmailOtpReferenceId nvarchar(200) NULL,
        MobileVerified bit NOT NULL CONSTRAINT DF_AgentRegistration_MobileVerified DEFAULT 0,
        EmailVerified bit NOT NULL CONSTRAINT DF_AgentRegistration_EmailVerified DEFAULT 0,
        MobileOtpAttemptCount int NOT NULL CONSTRAINT DF_AgentRegistration_MobileAttempts DEFAULT 0,
        EmailOtpAttemptCount int NOT NULL CONSTRAINT DF_AgentRegistration_EmailAttempts DEFAULT 0,
        MobileResendCount int NOT NULL CONSTRAINT DF_AgentRegistration_MobileResends DEFAULT 0,
        EmailResendCount int NOT NULL CONSTRAINT DF_AgentRegistration_EmailResends DEFAULT 0,
        MobileLastSentUtc datetime2(3) NULL,
        EmailLastSentUtc datetime2(3) NULL,
        Status varchar(10) NOT NULL CONSTRAINT DF_AgentRegistration_Status DEFAULT 'Pending',
        CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_AgentRegistration_CreatedUtc DEFAULT SYSUTCDATETIME(),
        ExpiresUtc datetime2(3) NOT NULL,
        CompletedUtc datetime2(3) NULL,
        CONSTRAINT FK_AgentRegistration_UserMaster FOREIGN KEY (UserId) REFERENCES auth.UserMaster(UserId),
        CONSTRAINT CK_AgentRegistration_Status CHECK (Status IN ('Pending', 'Completed', 'Failed', 'Expired')),
        CONSTRAINT CK_AgentRegistration_Attempts CHECK
            (MobileOtpAttemptCount >= 0 AND EmailOtpAttemptCount >= 0 AND MobileResendCount >= 0 AND EmailResendCount >= 0)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'auth.AgentRegistration') AND name = N'IX_AgentRegistration_UserId')
    CREATE INDEX IX_AgentRegistration_UserId ON auth.AgentRegistration(UserId, CreatedUtc DESC);
GO

CREATE OR ALTER PROCEDURE auth.usp_Registration_Create
    @FullName nvarchar(160), @PrimaryMobile nvarchar(20), @PrimaryEmail nvarchar(254),
    @AlternateMobile nvarchar(20) = NULL, @AlternateEmail nvarchar(254) = NULL,
    @PasswordHash nvarchar(512), @ExpiresHours int,
    @RegistrationId uniqueidentifier OUTPUT, @AgentCode nvarchar(40) OUTPUT,
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @UserId uniqueidentifier, @ExistingStatus varchar(10), @ExistingAgentCode nvarchar(40);
        SELECT @UserId = UserId, @ExistingStatus = Status, @ExistingAgentCode = AgentCode
        FROM auth.UserMaster WITH (UPDLOCK, HOLDLOCK)
        WHERE PrimaryEmailNormalized = UPPER(@PrimaryEmail) AND IsDeleted = 0;

        IF @UserId IS NOT NULL AND
            (@ExistingStatus <> 'Inactive' OR NOT EXISTS
            (
                SELECT 1 FROM auth.AgentRegistration WITH (UPDLOCK, HOLDLOCK)
                WHERE UserId = @UserId AND (Status = 'Expired' OR (Status = 'Pending' AND ExpiresUtc <= SYSUTCDATETIME()))
            ))
        BEGIN
            SET @ResultCode = 'DUPLICATE';
            COMMIT;
            RETURN;
        END;

        IF @UserId IS NULL
        BEGIN
            SET @UserId = NEWID();
            DECLARE @AgentSequence bigint = NEXT VALUE FOR auth.AgentCodeSequence;
            SET @AgentCode = N'AG' + RIGHT(N'00000000' + CONVERT(nvarchar(20), @AgentSequence), 8);
            INSERT auth.UserMaster
                (UserId, AgentCode, FullName, PrimaryEmail, AlternateEmail, PrimaryMobile,
                 AlternateMobile, PasswordHash, Status)
            VALUES
                (@UserId, @AgentCode, @FullName, @PrimaryEmail, @AlternateEmail, @PrimaryMobile,
                 @AlternateMobile, @PasswordHash, 'Inactive');
            INSERT auth.PasswordHistory(UserId, PasswordHash) VALUES (@UserId, @PasswordHash);
        END
        ELSE
        BEGIN
            SET @AgentCode = @ExistingAgentCode;
            UPDATE auth.AgentRegistration
            SET Status = 'Expired'
            WHERE UserId = @UserId AND Status = 'Pending' AND ExpiresUtc <= SYSUTCDATETIME();
            UPDATE auth.UserMaster
            SET FullName = @FullName, PrimaryMobile = @PrimaryMobile, AlternateMobile = @AlternateMobile,
                AlternateEmail = @AlternateEmail, PasswordHash = @PasswordHash,
                PasswordChangedUtc = SYSUTCDATETIME(), Status = 'Inactive',
                FailedLoginCount = 0, LockoutEndUtc = NULL, UpdatedUtc = SYSUTCDATETIME()
            WHERE UserId = @UserId;
            INSERT auth.PasswordHistory(UserId, PasswordHash) VALUES (@UserId, @PasswordHash);
        END;

        SET @RegistrationId = NEWID();
        INSERT auth.AgentRegistration(RegistrationId, UserId, ExpiresUtc)
        VALUES (@RegistrationId, @UserId, DATEADD(HOUR, @ExpiresHours, SYSUTCDATETIME()));
        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Registration_Get
    @RegistrationId uniqueidentifier, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        SELECT r.RegistrationId, r.UserId, u.AgentCode, u.PrimaryMobile, u.PrimaryEmail,
            r.MobileOtpReferenceId, r.EmailOtpReferenceId, r.MobileVerified, r.EmailVerified,
            r.MobileOtpAttemptCount, r.EmailOtpAttemptCount, r.Status, r.ExpiresUtc,
            r.MobileLastSentUtc, r.EmailLastSentUtc
        FROM auth.AgentRegistration AS r
        INNER JOIN auth.UserMaster AS u ON u.UserId = r.UserId
        WHERE r.RegistrationId = @RegistrationId;
        SET @ResultCode = IIF(@@ROWCOUNT = 0, 'NOT_FOUND', 'OK');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Registration_ReserveOtpSend
    @RegistrationId uniqueidentifier, @DestinationType varchar(20), @CooldownSeconds int,
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @Status varchar(10), @ExpiresUtc datetime2(3), @LastSentUtc datetime2(3), @Verified bit;
        SELECT @Status = Status, @ExpiresUtc = ExpiresUtc,
            @LastSentUtc = CASE WHEN @DestinationType = 'PrimaryMobile' THEN MobileLastSentUtc ELSE EmailLastSentUtc END,
            @Verified = CASE WHEN @DestinationType = 'PrimaryMobile' THEN MobileVerified ELSE EmailVerified END
        FROM auth.AgentRegistration WITH (UPDLOCK, ROWLOCK)
        WHERE RegistrationId = @RegistrationId;

        IF @Status IS NULL OR @Status <> 'Pending'
        BEGIN SET @ResultCode = 'INVALID_STATE'; COMMIT; RETURN; END;
        IF @ExpiresUtc <= SYSUTCDATETIME()
        BEGIN SET @ResultCode = 'EXPIRED'; COMMIT; RETURN; END;
        IF @Verified = 1
        BEGIN SET @ResultCode = 'ALREADY_VERIFIED'; COMMIT; RETURN; END;
        IF @LastSentUtc IS NOT NULL AND DATEDIFF(SECOND, @LastSentUtc, SYSUTCDATETIME()) < @CooldownSeconds
        BEGIN SET @ResultCode = 'COOLDOWN'; COMMIT; RETURN; END;

        IF @DestinationType = 'PrimaryMobile'
            UPDATE auth.AgentRegistration
            SET MobileOtpAttemptCount = IIF(MobileLastSentUtc IS NULL, MobileOtpAttemptCount, 0),
                MobileResendCount = MobileResendCount + IIF(MobileLastSentUtc IS NULL, 0, 1),
                MobileLastSentUtc = SYSUTCDATETIME(), MobileOtpReferenceId = NULL
            WHERE RegistrationId = @RegistrationId;
        ELSE IF @DestinationType = 'PrimaryEmail'
            UPDATE auth.AgentRegistration
            SET EmailOtpAttemptCount = IIF(EmailLastSentUtc IS NULL, EmailOtpAttemptCount, 0),
                EmailResendCount = EmailResendCount + IIF(EmailLastSentUtc IS NULL, 0, 1),
                EmailLastSentUtc = SYSUTCDATETIME(), EmailOtpReferenceId = NULL
            WHERE RegistrationId = @RegistrationId;
        ELSE
        BEGIN SET @ResultCode = 'INVALID_STATE'; COMMIT; RETURN; END;

        SET @ResultCode = 'OK';
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Registration_SaveOtpReference
    @RegistrationId uniqueidentifier, @DestinationType varchar(20), @OtpReferenceId nvarchar(200),
    @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        IF @DestinationType = 'PrimaryMobile'
            UPDATE auth.AgentRegistration SET MobileOtpReferenceId = @OtpReferenceId
            WHERE RegistrationId = @RegistrationId AND Status = 'Pending'
                AND MobileVerified = 0 AND MobileLastSentUtc IS NOT NULL AND ExpiresUtc > SYSUTCDATETIME();
        ELSE IF @DestinationType = 'PrimaryEmail'
            UPDATE auth.AgentRegistration SET EmailOtpReferenceId = @OtpReferenceId
            WHERE RegistrationId = @RegistrationId AND Status = 'Pending'
                AND EmailVerified = 0 AND EmailLastSentUtc IS NOT NULL AND ExpiresUtc > SYSUTCDATETIME();
        ELSE
        BEGIN SET @ResultCode = 'INVALID_STATE'; RETURN; END;
        SET @ResultCode = IIF(@@ROWCOUNT = 1, 'OK', 'INVALID_STATE');
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE auth.usp_Registration_RecordOtpResult
    @RegistrationId uniqueidentifier, @DestinationType varchar(20), @IsValid bit, @MaxAttempts int,
    @IsComplete bit OUTPUT, @ResultCode varchar(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @Status varchar(10), @ExpiresUtc datetime2(3), @Attempts int, @AlreadyVerified bit,
            @MobileVerified bit, @EmailVerified bit, @UserId uniqueidentifier;
        SELECT @Status = Status, @ExpiresUtc = ExpiresUtc, @UserId = UserId,
            @Attempts = CASE WHEN @DestinationType = 'PrimaryMobile' THEN MobileOtpAttemptCount ELSE EmailOtpAttemptCount END,
            @AlreadyVerified = CASE WHEN @DestinationType = 'PrimaryMobile' THEN MobileVerified ELSE EmailVerified END,
            @MobileVerified = MobileVerified, @EmailVerified = EmailVerified
        FROM auth.AgentRegistration WITH (UPDLOCK, ROWLOCK)
        WHERE RegistrationId = @RegistrationId;
        SET @IsComplete = 0;
        IF @Status IS NULL OR @Status <> 'Pending'
        BEGIN SET @ResultCode = 'INVALID_STATE'; COMMIT; RETURN; END;
        IF @ExpiresUtc <= SYSUTCDATETIME()
        BEGIN SET @ResultCode = 'EXPIRED'; COMMIT; RETURN; END;
        IF @DestinationType NOT IN ('PrimaryMobile', 'PrimaryEmail')
        BEGIN SET @ResultCode = 'INVALID_STATE'; COMMIT; RETURN; END;
        IF @AlreadyVerified = 1
        BEGIN SET @ResultCode = 'OK'; COMMIT; RETURN; END;

        IF @IsValid = 0
        BEGIN
            IF @DestinationType = 'PrimaryMobile'
                UPDATE auth.AgentRegistration SET MobileOtpAttemptCount = MobileOtpAttemptCount + 1
                WHERE RegistrationId = @RegistrationId;
            ELSE
                UPDATE auth.AgentRegistration SET EmailOtpAttemptCount = EmailOtpAttemptCount + 1
                WHERE RegistrationId = @RegistrationId;

            SET @ResultCode = IIF(@Attempts + 1 >= @MaxAttempts, 'ATTEMPTS_EXCEEDED', 'OTP_INVALID');
            COMMIT;
            RETURN;
        END;

        IF @DestinationType = 'PrimaryMobile' SET @MobileVerified = 1;
        ELSE SET @EmailVerified = 1;

        UPDATE auth.AgentRegistration
        SET MobileVerified = @MobileVerified, EmailVerified = @EmailVerified
        WHERE RegistrationId = @RegistrationId;

        IF @MobileVerified = 1 AND @EmailVerified = 1
        BEGIN
            UPDATE auth.UserMaster SET Status = 'Active', UpdatedUtc = SYSUTCDATETIME()
            WHERE UserId = @UserId AND IsDeleted = 0 AND Status = 'Inactive';
            IF @@ROWCOUNT <> 1
            BEGIN SET @ResultCode = 'INVALID_STATE'; ROLLBACK; RETURN; END;
            UPDATE auth.AgentRegistration SET Status = 'Completed', CompletedUtc = SYSUTCDATETIME()
            WHERE RegistrationId = @RegistrationId;
            SET @IsComplete = 1;
            SET @ResultCode = 'COMPLETED';
        END
        ELSE SET @ResultCode = 'OK';

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO

MERGE auth.ApplicationSetting AS target
USING (VALUES
    (N'RegistrationOtpMaxAttempts', N'3'),
    (N'RegistrationOtpCooldownSeconds', N'30'),
    (N'RegistrationExpiresHours', N'24')
) AS source(SettingKey, SettingValue)
ON target.SettingKey = source.SettingKey
WHEN NOT MATCHED THEN
    INSERT (SettingKey, SettingValue) VALUES (source.SettingKey, source.SettingValue);
GO
