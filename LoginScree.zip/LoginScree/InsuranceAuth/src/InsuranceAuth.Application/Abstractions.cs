using InsuranceAuth.Domain;

namespace InsuranceAuth.Application;

public interface IUserRepository
{
    Task<User?> GetByLoginIdAsync(string loginId, CancellationToken cancellationToken);
    Task<User?> GetByIdAsync(Guid userId, CancellationToken cancellationToken);
    Task<LoginFailureResult> RegisterFailureAsync(Guid userId, int maxAttempts, int lockoutMinutes, CancellationToken cancellationToken);
    Task<ResultCode> RegisterSuccessAsync(Guid userId, CancellationToken cancellationToken);
}

public interface IResetRepository
{
    Task<(Guid? ResetId, ResultCode Result)> CreateAsync(Guid userId, int maxPerHour, string? ipAddress, CancellationToken cancellationToken);
    Task<ResetRequest?> GetByIdAsync(Guid resetId, CancellationToken cancellationToken);
    Task<ResultCode> SetOtpSentAsync(Guid resetId, string destinationType, string? otpReferenceId, int cooldownSeconds, CancellationToken cancellationToken);
    Task<OtpFailureResult> RegisterOtpFailureAsync(Guid resetId, int maxAttempts, CancellationToken cancellationToken);
    Task<ResultCode> MarkVerifiedAsync(Guid resetId, byte[] tokenHash, DateTime expiresUtc, CancellationToken cancellationToken);
    Task<ResetRequest?> GetByTokenHashAsync(byte[] tokenHash, CancellationToken cancellationToken);
    Task<IReadOnlyList<PasswordHistoryEntry>> GetLastPasswordsAsync(Guid userId, int count, CancellationToken cancellationToken);
    Task<ResultCode> UpdatePasswordAsync(Guid userId, Guid resetId, string passwordHash, CancellationToken cancellationToken);
}

public interface IRegistrationRepository
{
    Task<(Guid? RegistrationId, string? AgentCode, ResultCode Result)> CreateAsync(
        string fullName, string primaryMobile, string primaryEmail, string? alternateMobile,
        string? alternateEmail, string passwordHash, int expiresHours, CancellationToken cancellationToken);
    Task<RegistrationRecord?> GetAsync(Guid registrationId, CancellationToken cancellationToken);
    Task<ResultCode> ReserveOtpSendAsync(
        Guid registrationId, string destinationType, int cooldownSeconds, CancellationToken cancellationToken);
    Task<ResultCode> SaveOtpReferenceAsync(
        Guid registrationId, string destinationType, string otpReferenceId, CancellationToken cancellationToken);
    Task<(ResultCode Result, bool IsComplete)> RecordOtpResultAsync(
        Guid registrationId, string destinationType, bool isValid, int maxAttempts, CancellationToken cancellationToken);
}

public interface ISessionRepository
{
    Task<ResultCode> CreateAsync(UserSession session, CancellationToken cancellationToken);
    Task<ResultCode> RevokeAsync(Guid userId, Guid sessionId, string reason, CancellationToken cancellationToken);
    Task RevokeAllByUserAsync(Guid userId, string reason, CancellationToken cancellationToken);
}

public interface IAuditRepository
{
    Task InsertAsync(Guid? userId, string? loginId, string eventType, bool isSuccess,
        string? failureReason, string? ipAddress, CancellationToken cancellationToken);
}

public interface ICaptchaClient
{
    Task<bool> ValidateAsync(string captchaId, string captchaText, CancellationToken cancellationToken);
}

public interface IOtpClient
{
    Task<string> SendAsync(string destinationType, string destinationValue, string purpose, CancellationToken cancellationToken);
    Task<bool> VerifyAsync(string otpReferenceId, string otp, CancellationToken cancellationToken);
}

public interface ITokenService
{
    Task<TokenIssue> IssueAsync(User user, Guid sessionId, CancellationToken cancellationToken);
}

public interface IPasswordHasher
{
    Task<string> HashAsync(string password, CancellationToken cancellationToken);
    Task<bool> VerifyAsync(string password, string hash, CancellationToken cancellationToken);
    Task BurnTimeAsync(string password, CancellationToken cancellationToken);
}

public interface IDevSeedRepository
{
    Task<Guid> UpsertUserAsync(User user, CancellationToken cancellationToken);
}

public sealed class AuthOptions
{
    public int MaxFailedAttempts { get; set; } = 4;
    public int LockoutMinutes { get; set; } = 15;
    public int ResetRequestsPerHour { get; set; } = 3;
    public int ResetOtpMaxAttempts { get; set; } = 3;
    public int ResetOtpCooldownSeconds { get; set; } = 30;
    public int ResetTokenMinutes { get; set; } = 10;
    public int PasswordHistoryCount { get; set; } = 5;
    public int MinimumPasswordLength { get; set; } = 10;
    public int RegistrationOtpMaxAttempts { get; set; } = 3;
    public int RegistrationOtpCooldownSeconds { get; set; } = 30;
    public int RegistrationExpiresHours { get; set; } = 24;
}

public sealed class ExternalApiOptions
{
    public ExternalServiceOptions Captcha { get; set; } = new();
    public ExternalServiceOptions Otp { get; set; } = new();
    public ExternalServiceOptions Token { get; set; } = new();
}

public sealed class ExternalServiceOptions
{
    public string BaseUrl { get; set; } = "";
    public string ApiKey { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 10;
    public string ValidatePath { get; set; } = "validate";
    public string SendPath { get; set; } = "send";
    public string VerifyPath { get; set; } = "verify";
    public string IssuePath { get; set; } = "issue";
}

public sealed record LoginRequest(string LoginId, string Password);
/// <summary>Information entered on the agent account registration form.</summary>
public sealed record RegisterAgentRequest(
    string FullName, string MobileNumber, string Email, string? AlternateMobile,
    string? AlternateEmail, string Password);
/// <summary>Request an OTP for a pending account registration.</summary>
public sealed record SendRegistrationOtpRequest(Guid RegistrationId, string DestinationType);
/// <summary>Verify the mobile and email OTPs sent during account registration.</summary>
public sealed record VerifyRegistrationRequest(Guid RegistrationId, string MobileOtp, string EmailOtp);
/// <summary>Details returned after an agent account registration request.</summary>
public sealed record RegistrationStartedResult(
    Guid RegistrationId, string AgentCode, bool RequiresVerification, DateTimeOffset ExpiresUtc);
/// <summary>Result of verifying the registered mobile and email addresses.</summary>
public sealed record RegistrationVerifiedResult(string AgentCode, bool IsActive);
public sealed record LoginResult(string AccessToken, string RefreshToken, DateTime ExpiresUtc, Guid SessionId, AgentProfile User);
public sealed record IdentifyResetRequest(string LoginId, string CaptchaId, string CaptchaText);
public sealed record ResetIdentifyResult(Guid? ResetId, IReadOnlyList<MaskedDestination> Destinations);
public sealed record MaskedDestination(string DestinationType, string MaskedValue);
public sealed record SendOtpRequest(Guid ResetId, string DestinationType);
public sealed record VerifyOtpRequest(Guid ResetId, string Otp);
public sealed record VerifyOtpResult(string ResetToken, DateTime ExpiresUtc);
public sealed record NewPasswordRequest(string ResetToken, string NewPassword);
public sealed record ClientContext(string? IpAddress, string? UserAgent, string? DeviceInfo);

public sealed record ApiEnvelope<T>(
    bool Success, string Message, T? Data, IReadOnlyList<string>? Errors, string? ErrorCode);

public static class ApiResult
{
    public static ApiEnvelope<T> Ok<T>(T data, string message = "Success") => new(true, message, data, null, null);
    public static ApiEnvelope<T> Fail<T>(string message, string errorCode, IReadOnlyList<string>? errors = null, T? data = default)
        => new(false, message, data, errors, errorCode);
}
