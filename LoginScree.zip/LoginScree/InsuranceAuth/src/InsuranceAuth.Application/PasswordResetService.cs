using System.Security.Cryptography;
using System.Text;
using FluentValidation;
using InsuranceAuth.Domain;

namespace InsuranceAuth.Application;

public sealed class PasswordResetService(
    IUserRepository users,
    IResetRepository resets,
    IAuditRepository audit,
    ICaptchaClient captcha,
    IOtpClient otp,
    IPasswordHasher passwordHasher,
    IValidator<IdentifyResetRequest> identifyValidator,
    IValidator<SendOtpRequest> sendValidator,
    IValidator<VerifyOtpRequest> verifyValidator,
    IValidator<NewPasswordRequest> passwordValidator,
    AuthOptions options)
{
    public async Task<ResetIdentifyResult> IdentifyAsync(
        IdentifyResetRequest request, string? ipAddress, CancellationToken cancellationToken)
    {
        await identifyValidator.ValidateAndThrowAsync(request, cancellationToken);
        if (!await captcha.ValidateAsync(request.CaptchaId, request.CaptchaText, cancellationToken))
            throw new AuthException("CAPTCHA_INVALID", "The CAPTCHA could not be validated.", 400);

        var user = await users.GetByLoginIdAsync(request.LoginId.Trim(), cancellationToken);
        if (user is null || user.Status != "Active")
        {
            await audit.InsertAsync(user?.UserId, request.LoginId, "PasswordReset", false,
                "NotIdentified", ipAddress, cancellationToken);
            return new ResetIdentifyResult(null, Array.Empty<MaskedDestination>());
        }

        var (resetId, result) = await resets.CreateAsync(user.UserId, options.ResetRequestsPerHour, ipAddress, cancellationToken);
        if (result == ResultCode.LimitExceeded)
            throw new AuthException("RESET_LIMIT_EXCEEDED", "Too many reset requests. Try again later.", 429);
        if (result != ResultCode.Ok || resetId is null)
            throw new AuthException("RESET_NOT_AVAILABLE", "Password reset is not available for this account.", 400);

        var destinations = new List<MaskedDestination>
        {
            new("PrimaryMobile", MaskMobile(user.PrimaryMobile)),
            new("PrimaryEmail", MaskEmail(user.PrimaryEmail))
        };
        if (!string.IsNullOrWhiteSpace(user.AlternateMobile))
            destinations.Add(new("AlternateMobile", MaskMobile(user.AlternateMobile)));
        if (!string.IsNullOrWhiteSpace(user.AlternateEmail))
            destinations.Add(new("AlternateEmail", MaskEmail(user.AlternateEmail)));

        await audit.InsertAsync(user.UserId, request.LoginId, "PasswordReset", true, "Identified", ipAddress, cancellationToken);
        return new ResetIdentifyResult(resetId, destinations);
    }

    public async Task SendOtpAsync(SendOtpRequest request, CancellationToken cancellationToken)
    {
        await sendValidator.ValidateAndThrowAsync(request, cancellationToken);
        var reset = await GetResetAsync(request.ResetId, cancellationToken);
        RequireStatus(reset, "Identified", "OtpSent");
        var user = await users.GetByIdAsync(reset.UserId, cancellationToken)
            ?? throw InvalidStep();
        var destination = request.DestinationType switch
        {
            "PrimaryMobile" => user.PrimaryMobile,
            "PrimaryEmail" => user.PrimaryEmail,
            "AlternateMobile" => user.AlternateMobile,
            "AlternateEmail" => user.AlternateEmail,
            _ => null
        };
        if (string.IsNullOrWhiteSpace(destination))
            throw InvalidStep();

        var reservation = await resets.SetOtpSentAsync(request.ResetId, request.DestinationType, null,
            options.ResetOtpCooldownSeconds, cancellationToken);
        EnsureSetOtpResult(reservation);
        var referenceId = await otp.SendAsync(request.DestinationType, destination, "PasswordReset", cancellationToken);
        var completed = await resets.SetOtpSentAsync(request.ResetId, request.DestinationType, referenceId,
            options.ResetOtpCooldownSeconds, cancellationToken);
        EnsureSetOtpResult(completed);
        await audit.InsertAsync(user.UserId, null, "OtpSent", true, null, reset.IpAddress, cancellationToken);
    }

    public async Task<VerifyOtpResult> VerifyOtpAsync(VerifyOtpRequest request, CancellationToken cancellationToken)
    {
        await verifyValidator.ValidateAndThrowAsync(request, cancellationToken);
        var reset = await GetResetAsync(request.ResetId, cancellationToken);
        RequireStatus(reset, "OtpSent");
        if (string.IsNullOrEmpty(reset.OtpReferenceId))
            throw InvalidStep();

        if (!await otp.VerifyAsync(reset.OtpReferenceId, request.Otp, cancellationToken))
        {
            var failure = await resets.RegisterOtpFailureAsync(reset.ResetId, options.ResetOtpMaxAttempts, cancellationToken);
            await audit.InsertAsync(reset.UserId, null, "OtpVerified", false,
                failure.IsFailed ? "AttemptLimitReached" : "InvalidOtp", reset.IpAddress, cancellationToken);
            throw new AuthException(failure.IsFailed ? "OTP_ATTEMPTS_EXCEEDED" : "OTP_INVALID",
                failure.IsFailed ? "The OTP attempt limit has been reached." : "The OTP is invalid.", 400);
        }

        var rawToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var tokenHash = SHA256.HashData(Encoding.UTF8.GetBytes(rawToken));
        var expiresUtc = DateTime.UtcNow.AddMinutes(options.ResetTokenMinutes);
        var marked = await resets.MarkVerifiedAsync(reset.ResetId, tokenHash, expiresUtc, cancellationToken);
        if (marked != ResultCode.Ok)
            throw InvalidStep();
        await audit.InsertAsync(reset.UserId, null, "OtpVerified", true, null, reset.IpAddress, cancellationToken);
        return new VerifyOtpResult(rawToken, expiresUtc);
    }

    public async Task CompleteAsync(NewPasswordRequest request, CancellationToken cancellationToken)
    {
        await passwordValidator.ValidateAndThrowAsync(request, cancellationToken);
        ValidatePasswordPolicy(request.NewPassword);
        var tokenHash = SHA256.HashData(Encoding.UTF8.GetBytes(request.ResetToken));
        var reset = await resets.GetByTokenHashAsync(tokenHash, cancellationToken)
            ?? throw new AuthException("RESET_TOKEN_INVALID", "The reset token is invalid or expired.", 400);
        var history = await resets.GetLastPasswordsAsync(reset.UserId, options.PasswordHistoryCount, cancellationToken);
        foreach (var previous in history)
        {
            if (await passwordHasher.VerifyAsync(request.NewPassword, previous.PasswordHash, cancellationToken))
                throw new AuthException("PASSWORD_REUSED", "Choose a password that has not been used recently.", 400);
        }

        var passwordHash = await passwordHasher.HashAsync(request.NewPassword, cancellationToken);
        var result = await resets.UpdatePasswordAsync(reset.UserId, reset.ResetId, passwordHash, cancellationToken);
        if (result != ResultCode.Ok)
            throw new AuthException("RESET_TOKEN_INVALID", "The reset token is invalid or expired.", 400);
        await audit.InsertAsync(reset.UserId, null, "PasswordReset", true, null, reset.IpAddress, cancellationToken);
    }

    private async Task<ResetRequest> GetResetAsync(Guid resetId, CancellationToken cancellationToken)
        => await resets.GetByIdAsync(resetId, cancellationToken) ?? throw InvalidStep();

    private static void RequireStatus(ResetRequest reset, params string[] allowed)
    {
        if (!allowed.Contains(reset.Status, StringComparer.Ordinal))
            throw InvalidStep();
    }

    private static void EnsureSetOtpResult(ResultCode result)
    {
        if (result == ResultCode.Cooldown)
            throw new AuthException("OTP_RESEND_COOLDOWN", "Wait before requesting another OTP.", 429);
        if (result != ResultCode.Ok)
            throw InvalidStep();
    }

    private void ValidatePasswordPolicy(string password)
    {
        if (password.Length < options.MinimumPasswordLength ||
            !password.Any(char.IsUpper) || !password.Any(char.IsLower) ||
            !password.Any(char.IsDigit) || !password.Any(c => !char.IsLetterOrDigit(c)))
            throw new AuthException("PASSWORD_POLICY_FAILED",
                $"Password must be at least {options.MinimumPasswordLength} characters and include uppercase, lowercase, a number, and a special character.", 400);
    }

    private static AuthException InvalidStep()
        => new("RESET_STEP_INVALID", "The password reset request is invalid or out of order.", 400);

    private static string MaskMobile(string mobile)
    {
        var digits = new string(mobile.Where(char.IsDigit).ToArray());
        if (digits.Length < 6) return "****";
        var local = digits.Length > 10 ? digits[^10..] : digits;
        var country = digits.Length > 10 ? "+" + digits[..^10] + " " : "";
        return $"{country}{local[..2]}****{local[^2..]}";
    }

    private static string MaskEmail(string email)
    {
        var at = email.IndexOf('@');
        if (at < 1) return "****";
        return $"{email[..Math.Min(2, at)]}***{email[at..]}";
    }
}
