using FluentValidation;
using InsuranceAuth.Domain;

namespace InsuranceAuth.Application;

public sealed class AuthService(
    IUserRepository users,
    ISessionRepository sessions,
    IAuditRepository audit,
    IPasswordHasher passwordHasher,
    ITokenService tokens,
    IValidator<LoginRequest> loginValidator,
    AuthOptions options)
{
    public async Task<LoginResult> LoginAsync(LoginRequest request, ClientContext client, CancellationToken cancellationToken)
    {
        await loginValidator.ValidateAndThrowAsync(request, cancellationToken);
        var user = await users.GetByLoginIdAsync(request.LoginId.Trim(), cancellationToken);
        if (user is null)
        {
            await passwordHasher.BurnTimeAsync(request.Password, cancellationToken);
            await audit.InsertAsync(null, request.LoginId, "LoginFailed", false, "InvalidCredentials", client.IpAddress, cancellationToken);
            throw InvalidCredentials();
        }

        if (user.Status == "Locked" && user.LockoutEndUtc > DateTime.UtcNow)
        {
            await audit.InsertAsync(user.UserId, request.LoginId, "Locked", false, "LockoutActive", client.IpAddress, cancellationToken);
            throw Locked(user.LockoutEndUtc.Value);
        }

        if (user.Status != "Active" && !(user.Status == "Locked" && user.LockoutEndUtc <= DateTime.UtcNow))
        {
            await passwordHasher.BurnTimeAsync(request.Password, cancellationToken);
            await audit.InsertAsync(user.UserId, request.LoginId, "LoginFailed", false, "InvalidCredentials", client.IpAddress, cancellationToken);
            throw InvalidCredentials();
        }

        if (!await passwordHasher.VerifyAsync(request.Password, user.PasswordHash, cancellationToken))
        {
            var failure = await users.RegisterFailureAsync(user.UserId, options.MaxFailedAttempts, options.LockoutMinutes, cancellationToken);
            await audit.InsertAsync(user.UserId, request.LoginId, failure.IsLocked ? "Locked" : "LoginFailed",
                false, "InvalidCredentials", client.IpAddress, cancellationToken);
            if (failure.IsLocked)
                throw Locked(failure.LockoutEndUtc ?? DateTime.UtcNow.AddMinutes(options.LockoutMinutes));
            throw InvalidCredentials();
        }

        var loginResult = await users.RegisterSuccessAsync(user.UserId, cancellationToken);
        if (loginResult == ResultCode.Locked)
            throw Locked(user.LockoutEndUtc ?? DateTime.UtcNow.AddMinutes(options.LockoutMinutes));
        if (loginResult != ResultCode.Ok)
            throw InvalidCredentials();

        var sessionId = Guid.NewGuid();
        var issued = await tokens.IssueAsync(user, sessionId, cancellationToken);
        var result = await sessions.CreateAsync(new UserSession(
            sessionId, user.UserId, issued.TokenId, client.IpAddress, client.UserAgent,
            client.DeviceInfo, issued.ExpiresUtc), cancellationToken);
        if (result != ResultCode.Ok)
            throw new AuthException("SESSION_CREATE_FAILED", "The session could not be created.", 503);

        await audit.InsertAsync(user.UserId, request.LoginId, "LoginSuccess", true, null, client.IpAddress, cancellationToken);
        return new LoginResult(issued.AccessToken, issued.RefreshToken, issued.ExpiresUtc, sessionId, ToProfile(user));
    }

    public async Task LogoutAsync(Guid userId, Guid sessionId, CancellationToken cancellationToken)
    {
        var result = await sessions.RevokeAsync(userId, sessionId, "Logout", cancellationToken);
        if (result == ResultCode.NotFound)
            throw new AuthException("SESSION_NOT_FOUND", "The session was not found.", 404);
    }

    public Task LogoutAllAsync(Guid userId, CancellationToken cancellationToken)
        => sessions.RevokeAllByUserAsync(userId, "LogoutAll", cancellationToken);

    public async Task<AgentProfile> GetProfileAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await users.GetByIdAsync(userId, cancellationToken);
        return user is null
            ? throw new AuthException("USER_NOT_FOUND", "The user was not found.", 404)
            : ToProfile(user);
    }

    internal static AgentProfile ToProfile(User user)
        => new(user.UserId, user.AgentCode, user.IrdaLicenseNumber, user.FullName,
            user.PrimaryEmail, user.AlternateEmail, user.PrimaryMobile, user.AlternateMobile,
            user.PreferredLanguage, user.Status, user.MustChangePassword);

    private static AuthException InvalidCredentials()
        => new("INVALID_CREDENTIALS", "The login ID or password is incorrect.", 401);

    private static AuthException Locked(DateTime lockoutEndUtc)
        => new("ACCOUNT_LOCKED", "The account is temporarily locked.", 423,
            new { lockoutEndUtc });
}
