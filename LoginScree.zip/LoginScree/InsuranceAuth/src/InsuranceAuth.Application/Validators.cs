using FluentValidation;
using System.Net.Mail;

namespace InsuranceAuth.Application;

public sealed class LoginRequestValidator : AbstractValidator<LoginRequest>
{
    public LoginRequestValidator()
    {
        RuleFor(x => x.LoginId).NotEmpty().MaximumLength(254);
        RuleFor(x => x.Password).NotEmpty().MaximumLength(256);
    }
}

public sealed class IdentifyResetRequestValidator : AbstractValidator<IdentifyResetRequest>
{
    public IdentifyResetRequestValidator()
    {
        RuleFor(x => x.LoginId).NotEmpty().MaximumLength(254);
        RuleFor(x => x.CaptchaId).NotEmpty().MaximumLength(200);
        RuleFor(x => x.CaptchaText).NotEmpty().MaximumLength(30);
    }
}

public sealed class SendOtpRequestValidator : AbstractValidator<SendOtpRequest>
{
    public SendOtpRequestValidator()
    {
        RuleFor(x => x.ResetId).NotEmpty();
        RuleFor(x => x.DestinationType).Must(IsDestinationType)
            .WithMessage("Destination type is invalid.");
    }

    internal static bool IsDestinationType(string? value)
        => value is "PrimaryMobile" or "PrimaryEmail" or "AlternateMobile" or "AlternateEmail";
}

public sealed class VerifyOtpRequestValidator : AbstractValidator<VerifyOtpRequest>
{
    public VerifyOtpRequestValidator()
    {
        RuleFor(x => x.ResetId).NotEmpty();
        RuleFor(x => x.Otp).NotEmpty().MaximumLength(20);
    }
}

public sealed class NewPasswordRequestValidator : AbstractValidator<NewPasswordRequest>
{
    public NewPasswordRequestValidator()
    {
        RuleFor(x => x.ResetToken).NotEmpty().MaximumLength(200);
        RuleFor(x => x.NewPassword).NotEmpty().MaximumLength(256);
    }
}

public sealed class RegisterAgentRequestValidator : AbstractValidator<RegisterAgentRequest>
{
    public RegisterAgentRequestValidator()
    {
        RuleFor(x => x.FullName).NotEmpty().MaximumLength(160)
            .Must(value => value is not null && value.Trim().Length > 0)
            .WithMessage("Full name is required.");
        RuleFor(x => x.MobileNumber).NotEmpty().MaximumLength(20).Must(IsMobile)
            .WithMessage("Enter a valid mobile number.");
        RuleFor(x => x.Email).NotEmpty().EmailAddress().MaximumLength(254);
        RuleFor(x => x.AlternateMobile).Must(value => string.IsNullOrWhiteSpace(value) || IsMobile(value))
            .WithMessage("Enter a valid alternate mobile number.");
        RuleFor(x => x.AlternateEmail).Must(value => string.IsNullOrWhiteSpace(value) || IsEmail(value))
            .WithMessage("Enter a valid alternate email address.");
        RuleFor(x => x.Password).NotEmpty().MaximumLength(256);
    }

    internal static bool IsMobile(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        var digits = value.StartsWith('+') ? value[1..] : value;
        return digits.Length is >= 10 and <= 15 && digits.All(char.IsDigit);
    }

    private static bool IsEmail(string value)
    {
        try
        {
            return new MailAddress(value).Address.Equals(value, StringComparison.OrdinalIgnoreCase);
        }
        catch (FormatException)
        {
            return false;
        }
    }
}

public sealed class SendRegistrationOtpRequestValidator : AbstractValidator<SendRegistrationOtpRequest>
{
    public SendRegistrationOtpRequestValidator()
    {
        RuleFor(x => x.RegistrationId).NotEmpty();
        RuleFor(x => x.DestinationType).Must(value => value is "PrimaryMobile" or "PrimaryEmail")
            .WithMessage("Destination type must be PrimaryMobile or PrimaryEmail.");
    }
}

public sealed class VerifyRegistrationRequestValidator : AbstractValidator<VerifyRegistrationRequest>
{
    public VerifyRegistrationRequestValidator()
    {
        RuleFor(x => x.RegistrationId).NotEmpty();
        RuleFor(x => x.MobileOtp).NotEmpty().MaximumLength(20);
        RuleFor(x => x.EmailOtp).NotEmpty().MaximumLength(20);
    }
}
