using FluentValidation;
using InsuranceAuth.Domain;

namespace InsuranceAuth.Application;

public sealed class RegistrationService(
    IRegistrationRepository registrations,
    IPasswordHasher passwordHasher,
    IOtpClient otp,
    IValidator<RegisterAgentRequest> registrationValidator,
    IValidator<SendRegistrationOtpRequest> sendOtpValidator,
    IValidator<VerifyRegistrationRequest> verifyValidator,
    AuthOptions options)
{
    public async Task<RegistrationStartedResult> RegisterAsync(
        RegisterAgentRequest request, CancellationToken cancellationToken)
    {
        await registrationValidator.ValidateAndThrowAsync(request, cancellationToken);
        ValidatePassword(request.Password);
        var passwordHash = await passwordHasher.HashAsync(request.Password, cancellationToken);
        var (registrationId, agentCode, result) = await registrations.CreateAsync(
            request.FullName.Trim(),
            request.MobileNumber.Trim(),
            request.Email.Trim().ToLowerInvariant(),
            NormalizeOptional(request.AlternateMobile),
            NormalizeOptional(request.AlternateEmail)?.ToLowerInvariant(),
            passwordHash,
            options.RegistrationExpiresHours,
            cancellationToken);

        if (result == ResultCode.Duplicate)
            throw new AuthException("EMAIL_ALREADY_REGISTERED", "An account already uses this email address.", 409);
        if (result != ResultCode.Ok || registrationId is null || string.IsNullOrWhiteSpace(agentCode))
            throw new AuthException("REGISTRATION_FAILED", "The account could not be registered.", 400);

        await SendOtpAsync(new SendRegistrationOtpRequest(registrationId.Value, "PrimaryMobile"), cancellationToken);
        await SendOtpAsync(new SendRegistrationOtpRequest(registrationId.Value, "PrimaryEmail"), cancellationToken);

        var registration = await GetPendingAsync(registrationId.Value, cancellationToken);
        return new RegistrationStartedResult(registrationId.Value, agentCode, true,
            new DateTimeOffset(DateTime.SpecifyKind(registration.ExpiresUtc, DateTimeKind.Utc)));
    }

    public async Task SendOtpAsync(
        SendRegistrationOtpRequest request, CancellationToken cancellationToken)
    {
        await sendOtpValidator.ValidateAndThrowAsync(request, cancellationToken);
        var registration = await GetPendingAsync(request.RegistrationId, cancellationToken);
        if (IsVerified(registration, request.DestinationType))
            throw new AuthException("DESTINATION_ALREADY_VERIFIED", "This contact detail is already verified.", 409);

        var result = await registrations.ReserveOtpSendAsync(
            registration.RegistrationId, request.DestinationType,
            options.RegistrationOtpCooldownSeconds, cancellationToken);
        if (result == ResultCode.Cooldown)
            throw new AuthException("OTP_RESEND_COOLDOWN", "Wait before requesting another OTP.", 429);
        if (result != ResultCode.Ok)
            throw InvalidRegistration();

        var destination = request.DestinationType == "PrimaryMobile"
            ? registration.PrimaryMobile
            : registration.PrimaryEmail;
        string referenceId;
        try
        {
            referenceId = await otp.SendAsync(request.DestinationType, destination, "AgentRegistration", cancellationToken);
        }
        catch (HttpRequestException)
        {
            throw new AuthException("OTP_DELIVERY_FAILED",
                "The verification code could not be sent. Retry after the resend cooldown.",
                503, new { registrationId = registration.RegistrationId, destinationType = request.DestinationType });
        }
        var saved = await registrations.SaveOtpReferenceAsync(
            registration.RegistrationId, request.DestinationType, referenceId, cancellationToken);
        if (saved != ResultCode.Ok)
            throw InvalidRegistration();
    }

    public async Task<RegistrationVerifiedResult> VerifyAsync(
        VerifyRegistrationRequest request, CancellationToken cancellationToken)
    {
        await verifyValidator.ValidateAndThrowAsync(request, cancellationToken);
        var registration = await registrations.GetAsync(request.RegistrationId, cancellationToken)
            ?? throw InvalidRegistration();
        if (registration.Status == "Completed")
            return new RegistrationVerifiedResult(registration.AgentCode, true);
        if (registration.Status != "Pending" || registration.ExpiresUtc <= DateTime.UtcNow)
            throw InvalidRegistration();

        await VerifyDestinationAsync(registration, "PrimaryMobile", request.MobileOtp, cancellationToken);
        registration = await GetPendingAsync(request.RegistrationId, cancellationToken);
        await VerifyDestinationAsync(registration, "PrimaryEmail", request.EmailOtp, cancellationToken);

        var updated = await registrations.GetAsync(request.RegistrationId, cancellationToken)
            ?? throw InvalidRegistration();
        return new RegistrationVerifiedResult(updated.AgentCode, updated.Status == "Completed");
    }

    private async Task VerifyDestinationAsync(
        RegistrationRecord registration, string destinationType, string providedOtp,
        CancellationToken cancellationToken)
    {
        if (IsVerified(registration, destinationType))
            return;

        var referenceId = destinationType == "PrimaryMobile"
            ? registration.MobileOtpReferenceId
            : registration.EmailOtpReferenceId;
        if (string.IsNullOrWhiteSpace(referenceId))
            throw new AuthException("OTP_NOT_SENT", "Request an OTP before verifying this contact detail.", 400);

        var isValid = await otp.VerifyAsync(referenceId, providedOtp, cancellationToken);
        var result = await registrations.RecordOtpResultAsync(registration.RegistrationId,
            destinationType, isValid, options.RegistrationOtpMaxAttempts, cancellationToken);
        if (result.Result == ResultCode.AttemptsExceeded)
            throw new AuthException("OTP_ATTEMPTS_EXCEEDED", "The OTP attempt limit has been reached.", 400);
        if (result.Result == ResultCode.OtpInvalid)
            throw new AuthException("OTP_INVALID", "The OTP is invalid.", 400);
        if (result.Result == ResultCode.Expired)
            throw InvalidRegistration();
        if (result.Result is not (ResultCode.Ok or ResultCode.Completed))
            throw InvalidRegistration();
    }

    private async Task<RegistrationRecord> GetPendingAsync(Guid registrationId, CancellationToken cancellationToken)
    {
        var registration = await registrations.GetAsync(registrationId, cancellationToken)
            ?? throw InvalidRegistration();
        if (registration.Status != "Pending" || registration.ExpiresUtc <= DateTime.UtcNow)
            throw InvalidRegistration();
        return registration;
    }

    private void ValidatePassword(string password)
    {
        if (password.Length < options.MinimumPasswordLength ||
            !password.Any(char.IsUpper) || !password.Any(char.IsLower) ||
            !password.Any(char.IsDigit) || !password.Any(c => !char.IsLetterOrDigit(c)))
            throw new AuthException("PASSWORD_POLICY_FAILED",
                $"Password must be at least {options.MinimumPasswordLength} characters and include uppercase, lowercase, a number, and a special character.", 400);
    }

    private static bool IsVerified(RegistrationRecord registration, string destinationType)
        => destinationType == "PrimaryMobile" ? registration.MobileVerified : registration.EmailVerified;

    private static string? NormalizeOptional(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static AuthException InvalidRegistration()
        => new("REGISTRATION_INVALID", "The registration request is invalid or expired.", 400);
}
