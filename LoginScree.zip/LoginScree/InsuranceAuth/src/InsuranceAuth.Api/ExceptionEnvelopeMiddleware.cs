using FluentValidation;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceAuth.Api;

public sealed class ExceptionEnvelopeMiddleware(
    RequestDelegate next,
    ILogger<ExceptionEnvelopeMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception exception) when (!context.Response.HasStarted)
        {
            var (status, code, message, errors, data) = exception switch
            {
                AuthException auth => (auth.StatusCode, auth.ErrorCode, auth.Message, (IReadOnlyList<string>?)null, auth.AdditionalData),
                ValidationException validation => (400, "VALIDATION_FAILED", "The request is invalid.",
                    (IReadOnlyList<string>?)validation.Errors.Select(error => error.ErrorMessage).Distinct().ToArray(), null),
                _ => (500, "INTERNAL_ERROR", "An unexpected error occurred.", (IReadOnlyList<string>?)null, null)
            };

            if (status >= 500)
                logger.LogError(exception, "Unhandled authentication request error. TraceId: {TraceId}", context.TraceIdentifier);
            else
                logger.LogWarning("Authentication request rejected with {ErrorCode} and status {StatusCode}. TraceId: {TraceId}",
                    code, status, context.TraceIdentifier);

            context.Response.Clear();
            context.Response.StatusCode = status;
            var problem = new ProblemDetails
            {
                Status = status,
                Title = message,
                Detail = message,
                Instance = context.Request.Path
            };
            problem.Extensions["success"] = false;
            problem.Extensions["message"] = message;
            problem.Extensions["data"] = data;
            problem.Extensions["errors"] = errors;
            problem.Extensions["errorCode"] = code;
            await context.Response.WriteAsJsonAsync(problem,
                options: null, contentType: "application/problem+json", cancellationToken: context.RequestAborted);
        }
    }
}
