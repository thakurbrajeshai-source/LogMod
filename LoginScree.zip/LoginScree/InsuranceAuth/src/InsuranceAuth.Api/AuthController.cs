using System.Security.Claims;
using InsuranceAuth.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace InsuranceAuth.Api;

[ApiController]
[Route("api/auth")]
[EnableRateLimiting("auth")]
public sealed class AuthController(
    AuthService auth, PasswordResetService reset, RegistrationService registration) : ControllerBase
{
    /// <summary>Creates a pending agent account and sends OTPs to its mobile number and email.</summary>
    [HttpPost("register")]
    [ProducesResponseType(typeof(ApiEnvelope<RegistrationStartedResult>), StatusCodes.Status202Accepted)]
    [ProducesResponseType(typeof(ApiEnvelope<object>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ApiEnvelope<RegistrationStartedResult>>> Register(
        [FromBody] RegisterAgentRequest request, CancellationToken cancellationToken)
    {
        var result = await registration.RegisterAsync(request, cancellationToken);
        return Accepted(
            ApiResult.Ok(result, "Registration started. Verify both contact details to activate the account."));
    }

    /// <summary>Resends an OTP to a pending registration's mobile or email address.</summary>
    [HttpPost("register/send-otp")]
    [ProducesResponseType(typeof(ApiEnvelope<object>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiEnvelope<object>>> SendRegistrationOtp(
        [FromBody] SendRegistrationOtpRequest request, CancellationToken cancellationToken)
    {
        await registration.SendOtpAsync(request, cancellationToken);
        return Ok(ApiResult.Ok<object>(new { }, "Verification code sent."));
    }

    /// <summary>Verifies both OTPs and activates the pending account.</summary>
    [HttpPost("register/verify")]
    [ProducesResponseType(typeof(ApiEnvelope<RegistrationVerifiedResult>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiEnvelope<RegistrationVerifiedResult>>> VerifyRegistration(
        [FromBody] VerifyRegistrationRequest request, CancellationToken cancellationToken)
    {
        var result = await registration.VerifyAsync(request, cancellationToken);
        return Ok(ApiResult.Ok(result, result.IsActive
            ? "Contact details verified. The account is active."
            : "Contact detail verified. Verify the remaining contact detail."));
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(ApiEnvelope<LoginResult>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiEnvelope<LoginResult>>> Login(
        [FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        var result = await auth.LoginAsync(request, Context(), cancellationToken);
        return Ok(ApiResult.Ok(result, "Login successful."));
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<ActionResult<ApiEnvelope<object>>> Logout(CancellationToken cancellationToken)
    {
        await auth.LogoutAsync(UserId(), SessionId(), cancellationToken);
        return Ok(ApiResult.Ok<object>(new { }, "Logged out."));
    }

    [HttpPost("logout-all")]
    [Authorize]
    public async Task<ActionResult<ApiEnvelope<object>>> LogoutAll(CancellationToken cancellationToken)
    {
        await auth.LogoutAllAsync(UserId(), cancellationToken);
        return Ok(ApiResult.Ok<object>(new { }, "All sessions have been revoked."));
    }

    [HttpPost("reset/identify")]
    public async Task<ActionResult<ApiEnvelope<ResetIdentifyResult>>> Identify(
        [FromBody] IdentifyResetRequest request, CancellationToken cancellationToken)
    {
        var result = await reset.IdentifyAsync(request, ClientIp(), cancellationToken);
        return Ok(ApiResult.Ok(result, "If the details match an active account, password-reset options are available."));
    }

    [HttpPost("reset/send-otp")]
    public async Task<ActionResult<ApiEnvelope<object>>> SendOtp(
        [FromBody] SendOtpRequest request, CancellationToken cancellationToken)
    {
        await reset.SendOtpAsync(request, cancellationToken);
        return Ok(ApiResult.Ok<object>(new { }, "OTP sent."));
    }

    [HttpPost("reset/verify-otp")]
    public async Task<ActionResult<ApiEnvelope<VerifyOtpResult>>> VerifyOtp(
        [FromBody] VerifyOtpRequest request, CancellationToken cancellationToken)
    {
        var result = await reset.VerifyOtpAsync(request, cancellationToken);
        return Ok(ApiResult.Ok(result, "OTP verified."));
    }

    [HttpPost("reset/new-password")]
    public async Task<ActionResult<ApiEnvelope<object>>> NewPassword(
        [FromBody] NewPasswordRequest request, CancellationToken cancellationToken)
    {
        await reset.CompleteAsync(request, cancellationToken);
        return Ok(ApiResult.Ok<object>(new { }, "Password reset completed."));
    }

    private ClientContext Context()
        => new(ClientIp(), Request.Headers.UserAgent.ToString(), Request.Headers["X-Device-Info"].ToString());

    private string? ClientIp() => HttpContext.Connection.RemoteIpAddress?.ToString();

    private Guid UserId()
        => Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var userId)
            ? userId
            : throw new InsuranceAuth.Domain.AuthException("AUTHENTICATION_REQUIRED", "Authentication is required.", 401);

    private Guid SessionId()
        => Guid.TryParse(User.FindFirstValue("sid"), out var sessionId)
            ? sessionId
            : throw new InsuranceAuth.Domain.AuthException("SESSION_REQUIRED", "An active session is required.", 401);
}
