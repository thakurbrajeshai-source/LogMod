using InsuranceAuth.Application;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceAuth.Api;

public static class EnvelopeResponses
{
    public static async Task WriteFailureAsync(
        HttpContext context, int statusCode, string errorCode, string message,
        IReadOnlyList<string>? errors = null, CancellationToken cancellationToken = default)
    {
        context.Response.StatusCode = statusCode;
        var problem = new ProblemDetails
        {
            Status = statusCode,
            Title = message,
            Detail = message,
            Instance = context.Request.Path
        };
        problem.Extensions["success"] = false;
        problem.Extensions["message"] = message;
        problem.Extensions["data"] = null;
        problem.Extensions["errors"] = errors;
        problem.Extensions["errorCode"] = errorCode;
        await context.Response.WriteAsJsonAsync(problem,
            options: null, contentType: "application/problem+json", cancellationToken: cancellationToken);
    }
}
