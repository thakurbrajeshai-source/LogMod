using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace InsuranceAuth.Api;

public sealed class DevelopmentAuthenticationHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "DevelopmentBearer";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var header = Request.Headers.Authorization.ToString();
        if (!header.StartsWith("Bearer dev.", StringComparison.Ordinal))
            return Task.FromResult(AuthenticateResult.NoResult());
        var parts = header["Bearer ".Length..].Split('.');
        if (parts.Length != 3 || parts[0] != "dev" ||
            !Guid.TryParse(parts[1], out var userId) || !Guid.TryParse(parts[2], out var sessionId))
            return Task.FromResult(AuthenticateResult.Fail("Invalid development token."));

        var identity = new ClaimsIdentity(
        [
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim("sub", userId.ToString()),
            new Claim("sid", sessionId.ToString())
        ], SchemeName);
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, SchemeName);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }

    protected override Task HandleChallengeAsync(AuthenticationProperties properties)
        => EnvelopeResponses.WriteFailureAsync(Context, StatusCodes.Status401Unauthorized,
            "AUTHENTICATION_REQUIRED", "Authentication is required.", cancellationToken: Context.RequestAborted);

    protected override Task HandleForbiddenAsync(AuthenticationProperties properties)
        => EnvelopeResponses.WriteFailureAsync(Context, StatusCodes.Status403Forbidden,
            "FORBIDDEN", "Access is forbidden.", cancellationToken: Context.RequestAborted);
}
