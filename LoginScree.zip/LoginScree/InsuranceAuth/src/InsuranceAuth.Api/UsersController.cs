using System.Security.Claims;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceAuth.Api;

[ApiController]
[Route("api/users")]
[Authorize]
public sealed class UsersController(AuthService auth) : ControllerBase
{
    [HttpGet("me")]
    public async Task<ActionResult<ApiEnvelope<AgentProfile>>> Me(CancellationToken cancellationToken)
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        if (!Guid.TryParse(id, out var userId))
            throw new AuthException("AUTHENTICATION_REQUIRED", "Authentication is required.", 401);
        var profile = await auth.GetProfileAsync(userId, cancellationToken);
        return Ok(ApiResult.Ok(profile));
    }
}
