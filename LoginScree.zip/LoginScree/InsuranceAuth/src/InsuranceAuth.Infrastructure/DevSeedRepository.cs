using System.Data;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Polly;

namespace InsuranceAuth.Infrastructure;

public sealed class DevSeedRepository(ISqlConnectionFactory connections) : IDevSeedRepository
{
    public async Task<Guid> UpsertUserAsync(User user, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_DevSeed_UserUpsert", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@AgentCode", SqlDbType.NVarChar, 40, user.AgentCode);
        UserRepository.Add(command, "@IrdaLicenseNumber", SqlDbType.NVarChar, 60, user.IrdaLicenseNumber);
        UserRepository.Add(command, "@FullName", SqlDbType.NVarChar, 160, user.FullName);
        UserRepository.Add(command, "@PrimaryEmail", SqlDbType.NVarChar, 254, user.PrimaryEmail);
        UserRepository.Add(command, "@AlternateEmail", SqlDbType.NVarChar, 254, user.AlternateEmail);
        UserRepository.Add(command, "@PrimaryMobile", SqlDbType.NVarChar, 20, user.PrimaryMobile);
        UserRepository.Add(command, "@AlternateMobile", SqlDbType.NVarChar, 20, user.AlternateMobile);
        UserRepository.Add(command, "@PasswordHash", SqlDbType.NVarChar, 512, user.PasswordHash);
        var userId = UserRepository.Output(command, "@UserId", SqlDbType.UniqueIdentifier);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return (Guid)userId.Value;
    }
}

public sealed class DevUserSeeder(
    IHostEnvironment environment,
    IConfiguration configuration,
    IPasswordHasher hasher,
    IDevSeedRepository repository,
    ILogger<DevUserSeeder> logger)
{
    public async Task SeedAsync(CancellationToken cancellationToken)
    {
        if (!environment.IsDevelopment() || !configuration.GetValue<bool>("DevSeed:Enabled"))
            return;
        var password = configuration["DevSeed:Password"];
        if (string.IsNullOrWhiteSpace(password))
            throw new InvalidOperationException("DevSeed:Password must be configured when DevSeed:Enabled is true.");
        if (password.Length < 10 || !password.Any(char.IsUpper) || !password.Any(char.IsLower) || !password.Any(char.IsDigit))
            throw new InvalidOperationException("The development seed password must satisfy the configured password policy.");

        var now = DateTime.UtcNow;
        var user = new User(Guid.Empty, "AGENT001", "IRDA-DEMO-0001", "Demo Insurance Agent",
            "agent@example.test", "agent.alt@example.test", "+919876540021", "+919876540022",
            await hasher.HashAsync(password, cancellationToken), now, false, "en", "Active", 0, null, null);
        var userId = await repository.UpsertUserAsync(user, cancellationToken);
        logger.LogInformation("Development sample agent {AgentCode} seeded with user id {UserId}.", user.AgentCode, userId);
    }
}

public static class InfrastructureRegistration
{
    public static IServiceCollection AddInsuranceAuthInfrastructure(
        this IServiceCollection services, IConfiguration configuration, IHostEnvironment environment)
    {
        services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IResetRepository, ResetRepository>();
        services.AddScoped<IRegistrationRepository, RegistrationRepository>();
        services.AddScoped<ISessionRepository, SessionRepository>();
        services.AddScoped<IAuditRepository, AuditRepository>();
        services.AddScoped<IDevSeedRepository, DevSeedRepository>();
        services.AddScoped<DevUserSeeder>();
        services.AddSingleton<IPasswordHasher, Argon2idPasswordHasher>();

        services.Configure<ExternalApiOptions>(configuration.GetSection("ExternalApis"));
        if (environment.IsDevelopment())
        {
            services.AddSingleton<IConfigurationValues, ConfigurationValues>();
            services.AddSingleton<ICaptchaClient, DevelopmentCaptchaClient>();
            services.AddSingleton<IOtpClient, DevelopmentOtpClient>();
            services.AddSingleton<ITokenService, DevelopmentTokenService>();
            return services;
        }

        AddExternalClient<ICaptchaClient, CaptchaHttpClient>(services,
            configuration.GetSection("ExternalApis:Captcha"));
        AddExternalClient<IOtpClient, OtpHttpClient>(services,
            configuration.GetSection("ExternalApis:Otp"));
        AddExternalClient<ITokenService, TokenHttpClient>(services,
            configuration.GetSection("ExternalApis:Token"));
        return services;
    }

    private static void AddExternalClient<TInterface, TClient>(
        IServiceCollection services, IConfigurationSection section)
        where TInterface : class
        where TClient : class, TInterface
    {
        var options = section.Get<ExternalServiceOptions>()
            ?? throw new InvalidOperationException($"{section.Path} configuration is required.");
        var baseAddress = CreateBaseAddress(options.BaseUrl, section.Path);
        services.AddHttpClient<TInterface, TClient>((_, client) =>
        {
            client.BaseAddress = baseAddress;
            SetApiKey(options, client);
            client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds > 0 ? options.TimeoutSeconds : 10);
        }).AddPolicyHandler(Polly.Extensions.Http.HttpPolicyExtensions
            .HandleTransientHttpError().WaitAndRetryAsync(3, retry => TimeSpan.FromMilliseconds(200 * Math.Pow(2, retry))));
    }

    private static Uri CreateBaseAddress(string value, string configurationPath)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp))
            throw new InvalidOperationException(
                $"{configurationPath}:BaseUrl must be set to an absolute HTTP(S) URL when running outside Development.");
        return new Uri(uri.ToString().TrimEnd('/') + "/");
    }

    private static void SetApiKey(ExternalServiceOptions options, HttpClient client)
    {
        if (!string.IsNullOrWhiteSpace(options.ApiKey))
            client.DefaultRequestHeaders.Add("X-API-Key", options.ApiKey);
    }
}
