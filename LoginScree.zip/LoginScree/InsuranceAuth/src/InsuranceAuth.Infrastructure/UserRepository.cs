using System.Data;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Data.SqlClient;

namespace InsuranceAuth.Infrastructure;

public sealed class UserRepository(ISqlConnectionFactory connections) : IUserRepository
{
    public Task<User?> GetByLoginIdAsync(string loginId, CancellationToken cancellationToken)
        => ReadUserAsync("auth.usp_User_GetByLoginId", ("@LoginId", SqlDbType.NVarChar, 254, (object)loginId), cancellationToken);

    public Task<User?> GetByIdAsync(Guid userId, CancellationToken cancellationToken)
        => ReadUserAsync("auth.usp_User_GetById", ("@UserId", SqlDbType.UniqueIdentifier, 0, (object)userId), cancellationToken);

    public async Task<LoginFailureResult> RegisterFailureAsync(
        Guid userId, int maxAttempts, int lockoutMinutes, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Login_RegisterFailure", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        Add(command, "@MaxAttempts", SqlDbType.Int, 0, maxAttempts);
        Add(command, "@LockoutMinutes", SqlDbType.Int, 0, lockoutMinutes);
        var failed = Output(command, "@FailedLoginCount", SqlDbType.Int);
        var locked = Output(command, "@IsLocked", SqlDbType.Bit);
        var lockout = Output(command, "@LockoutEndUtc", SqlDbType.DateTime2);
        var result = Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        if (ReadResult(result) is not (ResultCode.Ok or ResultCode.Locked or ResultCode.NotFound or ResultCode.Inactive))
            throw new InvalidOperationException($"Login failure procedure returned unexpected result code '{result.Value}'.");
        return new LoginFailureResult((int)failed.Value, (bool)locked.Value,
            lockout.Value is DBNull ? null : (DateTime)lockout.Value);
    }

    public async Task<ResultCode> RegisterSuccessAsync(Guid userId, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Login_RegisterSuccess", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        var result = Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return ReadResult(result);
    }

    private async Task<User?> ReadUserAsync(
        string procedure, (string Name, SqlDbType Type, int Size, object Value) parameter, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand(procedure, connection) { CommandType = CommandType.StoredProcedure };
        Add(command, parameter.Name, parameter.Type, parameter.Size, parameter.Value);
        var result = Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        User? user;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            user = await reader.ReadAsync(cancellationToken) ? MapUser(reader) : null;
        if (UserRepository.ReadResult(result) is not (ResultCode.Ok or ResultCode.NotFound))
            throw new InvalidOperationException("User lookup stored procedure returned an unexpected result code.");
        return user;
    }

    private static User MapUser(SqlDataReader reader)
    {
        var userId = reader.GetOrdinal("UserId");
        var agent = reader.GetOrdinal("AgentCode");
        var irda = reader.GetOrdinal("IrdaLicenseNumber");
        var fullName = reader.GetOrdinal("FullName");
        var email = reader.GetOrdinal("PrimaryEmail");
        var alternateEmail = reader.GetOrdinal("AlternateEmail");
        var mobile = reader.GetOrdinal("PrimaryMobile");
        var alternateMobile = reader.GetOrdinal("AlternateMobile");
        var passwordHash = reader.GetOrdinal("PasswordHash");
        var passwordChanged = reader.GetOrdinal("PasswordChangedUtc");
        var mustChange = reader.GetOrdinal("MustChangePassword");
        var language = reader.GetOrdinal("PreferredLanguage");
        var status = reader.GetOrdinal("Status");
        var failures = reader.GetOrdinal("FailedLoginCount");
        var lockout = reader.GetOrdinal("LockoutEndUtc");
        var lastLogin = reader.GetOrdinal("LastLoginUtc");
        return new User(reader.GetGuid(userId), reader.GetString(agent), NullableString(reader, irda),
            reader.GetString(fullName), reader.GetString(email), NullableString(reader, alternateEmail),
            reader.GetString(mobile), NullableString(reader, alternateMobile), reader.GetString(passwordHash),
            reader.GetDateTime(passwordChanged), reader.GetBoolean(mustChange), reader.GetString(language),
            reader.GetString(status), reader.GetInt32(failures), NullableDateTime(reader, lockout),
            NullableDateTime(reader, lastLogin));
    }

    internal static void Add(SqlCommand command, string name, SqlDbType type, int size, object? value)
    {
        var parameter = command.Parameters.Add(name, type);
        if (size > 0) parameter.Size = size;
        parameter.Value = value ?? DBNull.Value;
    }

    internal static SqlParameter Output(SqlCommand command, string name, SqlDbType type, int size = 0)
    {
        var parameter = command.Parameters.Add(name, type);
        if (size > 0) parameter.Size = size;
        parameter.Direction = ParameterDirection.Output;
        return parameter;
    }

    internal static string NullableString(SqlDataReader reader, int ordinal)
        => reader.IsDBNull(ordinal) ? null! : reader.GetString(ordinal);

    internal static DateTime? NullableDateTime(SqlDataReader reader, int ordinal)
        => reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);

    internal static ResultCode ReadResult(SqlParameter parameter)
        => parameter.Value?.ToString()?.ToUpperInvariant() switch
        {
            "OK" => ResultCode.Ok,
            "NOT_FOUND" => ResultCode.NotFound,
            "LIMIT_EXCEEDED" => ResultCode.LimitExceeded,
            "COOLDOWN" => ResultCode.Cooldown,
            "INVALID_STATE" => ResultCode.InvalidState,
            "INVALID_TOKEN" => ResultCode.InvalidToken,
            "LOCKED" => ResultCode.Locked,
            "INACTIVE" => ResultCode.Inactive,
            "DUPLICATE" => ResultCode.Duplicate,
            "OTP_INVALID" => ResultCode.OtpInvalid,
            "ATTEMPTS_EXCEEDED" => ResultCode.AttemptsExceeded,
            "EXPIRED" => ResultCode.Expired,
            "ALREADY_VERIFIED" => ResultCode.AlreadyVerified,
            "COMPLETED" => ResultCode.Completed,
            _ => ResultCode.Unknown
        };

    internal static void EnsureResult(SqlParameter parameter)
    {
        var result = ReadResult(parameter);
        if (result != ResultCode.Ok)
            throw new InvalidOperationException($"Stored procedure returned unexpected result code '{parameter.Value}'.");
    }
}
