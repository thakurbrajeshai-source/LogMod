using System.Data;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Data.SqlClient;

namespace InsuranceAuth.Infrastructure;

public sealed class ResetRepository(ISqlConnectionFactory connections) : IResetRepository
{
    public async Task<(Guid? ResetId, ResultCode Result)> CreateAsync(
        Guid userId, int maxPerHour, string? ipAddress, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Reset_Create", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@MaxPerHour", SqlDbType.Int, 0, maxPerHour);
        UserRepository.Add(command, "@IpAddress", SqlDbType.VarChar, 45, ipAddress);
        var resetId = UserRepository.Output(command, "@ResetId", SqlDbType.UniqueIdentifier);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        var resultCode = UserRepository.ReadResult(result);
        return (resetId.Value is DBNull ? null : (Guid)resetId.Value, resultCode);
    }

    public Task<ResetRequest?> GetByIdAsync(Guid resetId, CancellationToken cancellationToken)
        => ReadResetAsync("auth.usp_Reset_GetById", "@ResetId", SqlDbType.UniqueIdentifier, 0, resetId, cancellationToken);

    public async Task<ResultCode> SetOtpSentAsync(
        Guid resetId, string destinationType, string? otpReferenceId, int cooldownSeconds,
        CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Reset_SetOtpSent", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@ResetId", SqlDbType.UniqueIdentifier, 0, resetId);
        UserRepository.Add(command, "@DestinationType", SqlDbType.VarChar, 20, destinationType);
        UserRepository.Add(command, "@OtpReferenceId", SqlDbType.NVarChar, 200, otpReferenceId);
        UserRepository.Add(command, "@ResendCooldownSeconds", SqlDbType.Int, 0, cooldownSeconds);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    public async Task<OtpFailureResult> RegisterOtpFailureAsync(
        Guid resetId, int maxAttempts, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Reset_RegisterOtpFailure", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@ResetId", SqlDbType.UniqueIdentifier, 0, resetId);
        UserRepository.Add(command, "@MaxAttempts", SqlDbType.Int, 0, maxAttempts);
        var count = UserRepository.Output(command, "@OtpAttemptCount", SqlDbType.Int);
        var failed = UserRepository.Output(command, "@IsFailed", SqlDbType.Bit);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        UserRepository.EnsureResult(result);
        return new OtpFailureResult((int)count.Value, (bool)failed.Value);
    }

    public async Task<ResultCode> MarkVerifiedAsync(
        Guid resetId, byte[] tokenHash, DateTime expiresUtc, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Reset_MarkVerified", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@ResetId", SqlDbType.UniqueIdentifier, 0, resetId);
        UserRepository.Add(command, "@ResetTokenHash", SqlDbType.VarBinary, 32, tokenHash);
        UserRepository.Add(command, "@TokenExpiresUtc", SqlDbType.DateTime2, 0, expiresUtc);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    public Task<ResetRequest?> GetByTokenHashAsync(byte[] tokenHash, CancellationToken cancellationToken)
        => ReadResetAsync("auth.usp_Reset_GetByTokenHash", "@ResetTokenHash", SqlDbType.VarBinary, 32, tokenHash, cancellationToken);

    public async Task<IReadOnlyList<PasswordHistoryEntry>> GetLastPasswordsAsync(
        Guid userId, int count, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_PasswordHistory_GetLast", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@Count", SqlDbType.Int, 0, count);
        await connection.OpenAsync(cancellationToken);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        var entries = new List<PasswordHistoryEntry>();
        var hash = reader.GetOrdinal("PasswordHash");
        var created = reader.GetOrdinal("CreatedUtc");
        while (await reader.ReadAsync(cancellationToken))
            entries.Add(new PasswordHistoryEntry(reader.GetString(hash), reader.GetDateTime(created)));
        return entries;
    }

    public async Task<ResultCode> UpdatePasswordAsync(
        Guid userId, Guid resetId, string passwordHash, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Password_Update", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@ResetId", SqlDbType.UniqueIdentifier, 0, resetId);
        UserRepository.Add(command, "@PasswordHash", SqlDbType.NVarChar, 512, passwordHash);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    private async Task<ResetRequest?> ReadResetAsync(
        string procedure, string parameterName, SqlDbType parameterType, int size,
        object parameterValue, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand(procedure, connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, parameterName, parameterType, size, parameterValue);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        ResetRequest? reset;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            reset = await reader.ReadAsync(cancellationToken) ? MapReset(reader) : null;
        if (UserRepository.ReadResult(result) is not (ResultCode.Ok or ResultCode.NotFound))
            throw new InvalidOperationException("Reset lookup stored procedure returned an unexpected result code.");
        return reset;
    }

    private static ResetRequest MapReset(SqlDataReader reader)
    {
        var resetId = reader.GetOrdinal("ResetId");
        var userId = reader.GetOrdinal("UserId");
        var destination = reader.GetOrdinal("DestinationType");
        var reference = reader.GetOrdinal("OtpReferenceId");
        var status = reader.GetOrdinal("Status");
        var otpCount = reader.GetOrdinal("OtpAttemptCount");
        var resendCount = reader.GetOrdinal("ResendCount");
        var lastSent = reader.GetOrdinal("LastSentUtc");
        var verified = reader.GetOrdinal("VerifiedUtc");
        var tokenHash = reader.GetOrdinal("ResetTokenHash");
        var tokenExpires = reader.GetOrdinal("ResetTokenExpiresUtc");
        var used = reader.GetOrdinal("UsedUtc");
        var requested = reader.GetOrdinal("RequestedUtc");
        var ip = reader.GetOrdinal("IpAddress");
        return new ResetRequest(reader.GetGuid(resetId), reader.GetGuid(userId),
            reader.IsDBNull(destination) ? null : reader.GetString(destination),
            reader.IsDBNull(reference) ? null : reader.GetString(reference), reader.GetString(status),
            reader.GetInt32(otpCount), reader.GetInt32(resendCount),
            UserRepository.NullableDateTime(reader, lastSent), UserRepository.NullableDateTime(reader, verified),
            reader.IsDBNull(tokenHash) ? null : (byte[])reader.GetValue(tokenHash),
            UserRepository.NullableDateTime(reader, tokenExpires), UserRepository.NullableDateTime(reader, used),
            reader.GetDateTime(requested), UserRepository.NullableString(reader, ip));
    }
}
