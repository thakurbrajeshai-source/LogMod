using System.Data;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Data.SqlClient;

namespace InsuranceAuth.Infrastructure;

public sealed class SessionRepository(ISqlConnectionFactory connections) : ISessionRepository
{
    public async Task<ResultCode> CreateAsync(UserSession session, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Session_Create", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@SessionId", SqlDbType.UniqueIdentifier, 0, session.SessionId);
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, session.UserId);
        UserRepository.Add(command, "@TokenId", SqlDbType.NVarChar, 200, session.TokenId);
        UserRepository.Add(command, "@IpAddress", SqlDbType.VarChar, 45, session.IpAddress);
        UserRepository.Add(command, "@UserAgent", SqlDbType.NVarChar, 512, session.UserAgent);
        UserRepository.Add(command, "@DeviceInfo", SqlDbType.NVarChar, 256, session.DeviceInfo);
        UserRepository.Add(command, "@ExpiresUtc", SqlDbType.DateTime2, 0, session.ExpiresUtc);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    public async Task<ResultCode> RevokeAsync(
        Guid userId, Guid sessionId, string reason, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Session_Revoke", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@SessionId", SqlDbType.UniqueIdentifier, 0, sessionId);
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@Reason", SqlDbType.NVarChar, 100, reason);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    public async Task RevokeAllByUserAsync(Guid userId, string reason, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Session_RevokeAllByUser", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@Reason", SqlDbType.NVarChar, 100, reason);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        UserRepository.EnsureResult(result);
    }
}

public sealed class AuditRepository(ISqlConnectionFactory connections) : IAuditRepository
{
    public async Task InsertAsync(
        Guid? userId, string? loginId, string eventType, bool isSuccess,
        string? failureReason, string? ipAddress, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Audit_Insert", connection) { CommandType = CommandType.StoredProcedure };
        UserRepository.Add(command, "@UserId", SqlDbType.UniqueIdentifier, 0, userId);
        UserRepository.Add(command, "@LoginIdEntered", SqlDbType.NVarChar, 254, loginId);
        UserRepository.Add(command, "@EventType", SqlDbType.VarChar, 20, eventType);
        UserRepository.Add(command, "@IsSuccess", SqlDbType.Bit, 0, isSuccess);
        UserRepository.Add(command, "@FailureReason", SqlDbType.NVarChar, 100, failureReason);
        UserRepository.Add(command, "@IpAddress", SqlDbType.VarChar, 45, ipAddress);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
