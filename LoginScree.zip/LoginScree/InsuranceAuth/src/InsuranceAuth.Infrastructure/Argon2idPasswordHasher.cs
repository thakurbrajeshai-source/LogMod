using System.Security.Cryptography;
using System.Text;
using Konscious.Security.Cryptography;
using InsuranceAuth.Application;

namespace InsuranceAuth.Infrastructure;

public sealed class Argon2idPasswordHasher : IPasswordHasher
{
    private const int MemoryKiB = 65536;
    private const int Iterations = 3;
    private const int Parallelism = 2;
    private const int SaltLength = 16;
    private const int HashLength = 32;
    private const string DummyHash = "$argon2id$v=19$m=65536,t=3,p=2$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";

    public Task<string> HashAsync(string password, CancellationToken cancellationToken)
        => Task.Run(() =>
        {
            cancellationToken.ThrowIfCancellationRequested();
            var salt = RandomNumberGenerator.GetBytes(SaltLength);
            var hash = Derive(password, salt, MemoryKiB, Iterations, Parallelism, cancellationToken);
            return $"$argon2id$v=19$m={MemoryKiB},t={Iterations},p={Parallelism}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
        }, cancellationToken);

    public Task<bool> VerifyAsync(string password, string hash, CancellationToken cancellationToken)
        => Task.Run(() => Verify(password, hash, cancellationToken), cancellationToken);

    public Task BurnTimeAsync(string password, CancellationToken cancellationToken)
        => VerifyAsync(password, DummyHash, cancellationToken);

    private static bool Verify(string password, string encoded, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            var parts = encoded.Split('$');
            if (parts.Length != 6 || parts[1] != "argon2id" || parts[2] != "v=19")
                return false;
            var settings = parts[3].Split(',').Select(x => int.Parse(x[2..], System.Globalization.CultureInfo.InvariantCulture)).ToArray();
            if (settings.Length != 3 || settings[0] is < 8192 or > 262144 ||
                settings[1] is < 1 or > 10 || settings[2] is < 1 or > 8)
                return false;
            var salt = Convert.FromBase64String(parts[4]);
            var expected = Convert.FromBase64String(parts[5]);
            if (salt.Length is < 8 or > 64 || expected.Length is < 16 or > 64)
                return false;
            var actual = Derive(password, salt, settings[0], settings[1], settings[2], cancellationToken, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (FormatException)
        {
            return false;
        }
        catch (ArgumentException)
        {
            return false;
        }
    }

    private static byte[] Derive(
        string password, byte[] salt, int memory, int iterations, int parallelism,
        CancellationToken cancellationToken, int outputLength = HashLength)
    {
        cancellationToken.ThrowIfCancellationRequested();
        using var argon = new Argon2id(Encoding.UTF8.GetBytes(password))
        {
            Salt = salt,
            MemorySize = memory,
            Iterations = iterations,
            DegreeOfParallelism = parallelism
        };
        return argon.GetBytes(outputLength);
    }
}
