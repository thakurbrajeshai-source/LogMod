using System.Data;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Data.SqlClient;

namespace InsuranceAuth.Infrastructure;

public sealed class RegistrationRepository(ISqlConnectionFactory connections) : IRegistrationRepository
{
    public async Task<(Guid? RegistrationId, string? AgentCode, ResultCode Result)> CreateAsync(
        string fullName, string primaryMobile, string primaryEmail, string? alternateMobile,
        string? alternateEmail, string passwordHash, int expiresHours, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Registration_Create", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@FullName", SqlDbType.NVarChar, 160, fullName);
        UserRepository.Add(command, "@PrimaryMobile", SqlDbType.NVarChar, 20, primaryMobile);
        UserRepository.Add(command, "@PrimaryEmail", SqlDbType.NVarChar, 254, primaryEmail);
        UserRepository.Add(command, "@AlternateMobile", SqlDbType.NVarChar, 20, alternateMobile);
        UserRepository.Add(command, "@AlternateEmail", SqlDbType.NVarChar, 254, alternateEmail);
        UserRepository.Add(command, "@PasswordHash", SqlDbType.NVarChar, 512, passwordHash);
        UserRepository.Add(command, "@ExpiresHours", SqlDbType.Int, 0, expiresHours);
        var registrationId = UserRepository.Output(command, "@RegistrationId", SqlDbType.UniqueIdentifier);
        var agentCode = UserRepository.Output(command, "@AgentCode", SqlDbType.NVarChar, 40);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return (
            registrationId.Value is DBNull ? null : (Guid)registrationId.Value,
            agentCode.Value is DBNull ? null : (string)agentCode.Value,
            UserRepository.ReadResult(result));
    }

    public async Task<RegistrationRecord?> GetAsync(Guid registrationId, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Registration_Get", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@RegistrationId", SqlDbType.UniqueIdentifier, 0, registrationId);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        RegistrationRecord? registration;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            registration = await reader.ReadAsync(cancellationToken) ? MapRegistration(reader) : null;
        if (UserRepository.ReadResult(result) is not (ResultCode.Ok or ResultCode.NotFound))
            throw new InvalidOperationException("Registration lookup returned an unexpected result code.");
        return registration;
    }

    public Task<ResultCode> ReserveOtpSendAsync(
        Guid registrationId, string destinationType, int cooldownSeconds, CancellationToken cancellationToken)
        => ExecuteWithResultAsync("auth.usp_Registration_ReserveOtpSend", command =>
        {
            UserRepository.Add(command, "@RegistrationId", SqlDbType.UniqueIdentifier, 0, registrationId);
            UserRepository.Add(command, "@DestinationType", SqlDbType.VarChar, 20, destinationType);
            UserRepository.Add(command, "@CooldownSeconds", SqlDbType.Int, 0, cooldownSeconds);
        }, cancellationToken);

    public Task<ResultCode> SaveOtpReferenceAsync(
        Guid registrationId, string destinationType, string otpReferenceId, CancellationToken cancellationToken)
        => ExecuteWithResultAsync("auth.usp_Registration_SaveOtpReference", command =>
        {
            UserRepository.Add(command, "@RegistrationId", SqlDbType.UniqueIdentifier, 0, registrationId);
            UserRepository.Add(command, "@DestinationType", SqlDbType.VarChar, 20, destinationType);
            UserRepository.Add(command, "@OtpReferenceId", SqlDbType.NVarChar, 200, otpReferenceId);
        }, cancellationToken);

    public async Task<(ResultCode Result, bool IsComplete)> RecordOtpResultAsync(
        Guid registrationId, string destinationType, bool isValid, int maxAttempts,
        CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand("auth.usp_Registration_RecordOtpResult", connection)
        {
            CommandType = CommandType.StoredProcedure
        };
        UserRepository.Add(command, "@RegistrationId", SqlDbType.UniqueIdentifier, 0, registrationId);
        UserRepository.Add(command, "@DestinationType", SqlDbType.VarChar, 20, destinationType);
        UserRepository.Add(command, "@IsValid", SqlDbType.Bit, 0, isValid);
        UserRepository.Add(command, "@MaxAttempts", SqlDbType.Int, 0, maxAttempts);
        var isComplete = UserRepository.Output(command, "@IsComplete", SqlDbType.Bit);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return (UserRepository.ReadResult(result), (bool)isComplete.Value);
    }

    private async Task<ResultCode> ExecuteWithResultAsync(
        string procedure, Action<SqlCommand> addParameters, CancellationToken cancellationToken)
    {
        await using var connection = connections.CreateConnection();
        await using var command = new SqlCommand(procedure, connection) { CommandType = CommandType.StoredProcedure };
        addParameters(command);
        var result = UserRepository.Output(command, "@ResultCode", SqlDbType.VarChar, 20);
        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return UserRepository.ReadResult(result);
    }

    private static RegistrationRecord MapRegistration(SqlDataReader reader)
    {
        var registrationId = reader.GetOrdinal("RegistrationId");
        var userId = reader.GetOrdinal("UserId");
        var agentCode = reader.GetOrdinal("AgentCode");
        var mobile = reader.GetOrdinal("PrimaryMobile");
        var email = reader.GetOrdinal("PrimaryEmail");
        var mobileReference = reader.GetOrdinal("MobileOtpReferenceId");
        var emailReference = reader.GetOrdinal("EmailOtpReferenceId");
        var mobileVerified = reader.GetOrdinal("MobileVerified");
        var emailVerified = reader.GetOrdinal("EmailVerified");
        var mobileAttempts = reader.GetOrdinal("MobileOtpAttemptCount");
        var emailAttempts = reader.GetOrdinal("EmailOtpAttemptCount");
        var status = reader.GetOrdinal("Status");
        var expires = reader.GetOrdinal("ExpiresUtc");
        var mobileSent = reader.GetOrdinal("MobileLastSentUtc");
        var emailSent = reader.GetOrdinal("EmailLastSentUtc");
        return new RegistrationRecord(reader.GetGuid(registrationId), reader.GetGuid(userId),
            reader.GetString(agentCode), reader.GetString(mobile), reader.GetString(email),
            UserRepository.NullableString(reader, mobileReference), UserRepository.NullableString(reader, emailReference),
            reader.GetBoolean(mobileVerified), reader.GetBoolean(emailVerified),
            reader.GetInt32(mobileAttempts), reader.GetInt32(emailAttempts), reader.GetString(status),
            reader.GetDateTime(expires), UserRepository.NullableDateTime(reader, mobileSent),
            UserRepository.NullableDateTime(reader, emailSent));
    }
}
