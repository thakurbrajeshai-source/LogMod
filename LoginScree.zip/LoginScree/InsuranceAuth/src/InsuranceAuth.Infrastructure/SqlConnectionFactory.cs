using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace InsuranceAuth.Infrastructure;

public interface ISqlConnectionFactory
{
    SqlConnection CreateConnection();
}

public sealed class SqlConnectionFactory(IConfiguration configuration) : ISqlConnectionFactory
{
    private readonly string _connectionString = configuration.GetConnectionString("AuthDatabase")
        ?? throw new InvalidOperationException("ConnectionStrings:AuthDatabase is required.");

    public SqlConnection CreateConnection() => new(_connectionString);
}
