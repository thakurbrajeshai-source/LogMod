using System.Net.Http.Json;
using System.Text.Json.Serialization;
using InsuranceAuth.Application;
using InsuranceAuth.Domain;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace InsuranceAuth.Infrastructure;

public sealed class CaptchaHttpClient(HttpClient client, IOptions<ExternalApiOptions> options) : ICaptchaClient
{
    public async Task<bool> ValidateAsync(string captchaId, string captchaText, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(options.Value.Captcha.ValidatePath,
            new CaptchaValidateRequest(captchaId, captchaText), cancellationToken);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<CaptchaValidateResponse>(cancellationToken: cancellationToken)
            ?? throw new HttpRequestException("CAPTCHA service returned an empty response.");
        return result.Valid;
    }
}

public sealed class OtpHttpClient(HttpClient client, IOptions<ExternalApiOptions> options) : IOtpClient
{
    public async Task<string> SendAsync(
        string destinationType, string destinationValue, string purpose, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(options.Value.Otp.SendPath,
            new OtpSendApiRequest(destinationType, destinationValue, purpose), cancellationToken);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<OtpSendApiResponse>(cancellationToken: cancellationToken)
            ?? throw new HttpRequestException("OTP service returned an empty send response.");
        if (string.IsNullOrWhiteSpace(result.OtpReferenceId))
            throw new HttpRequestException("OTP service response did not include otpReferenceId.");
        return result.OtpReferenceId;
    }

    public async Task<bool> VerifyAsync(string otpReferenceId, string otp, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(options.Value.Otp.VerifyPath,
            new OtpVerifyApiRequest(otpReferenceId, otp), cancellationToken);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<OtpVerifyApiResponse>(cancellationToken: cancellationToken)
            ?? throw new HttpRequestException("OTP service returned an empty verification response.");
        return result.Verified;
    }
}

public sealed class TokenHttpClient(HttpClient client, IOptions<ExternalApiOptions> options) : ITokenService
{
    public async Task<TokenIssue> IssueAsync(User user, Guid sessionId, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(options.Value.Token.IssuePath,
            new TokenIssueApiRequest(
                new TokenUser(user.UserId, user.AgentCode, user.FullName, user.PrimaryEmail, user.IrdaLicenseNumber),
                sessionId), cancellationToken);
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<TokenIssueApiResponse>(cancellationToken: cancellationToken)
            ?? throw new HttpRequestException("Token service returned an empty response.");
        if (string.IsNullOrWhiteSpace(result.AccessToken) || string.IsNullOrWhiteSpace(result.RefreshToken) ||
            string.IsNullOrWhiteSpace(result.TokenId) || result.ExpiresUtc == default)
            throw new HttpRequestException("Token service response did not include required token fields.");
        return new TokenIssue(result.AccessToken, result.RefreshToken,
            DateTime.SpecifyKind(result.ExpiresUtc, DateTimeKind.Utc), result.TokenId);
    }
}

public sealed class DevelopmentCaptchaClient(IConfigurationValues values) : ICaptchaClient
{
    public Task<bool> ValidateAsync(string captchaId, string captchaText, CancellationToken cancellationToken)
        => Task.FromResult(captchaId == values.CaptchaId && captchaText == values.CaptchaText);
}

public sealed class DevelopmentOtpClient(IConfigurationValues values) : IOtpClient
{
    public Task<string> SendAsync(
        string destinationType, string destinationValue, string purpose, CancellationToken cancellationToken)
        => Task.FromResult("dev-" + Guid.NewGuid().ToString("N"));

    public Task<bool> VerifyAsync(string otpReferenceId, string otp, CancellationToken cancellationToken)
        => Task.FromResult(otpReferenceId.StartsWith("dev-", StringComparison.Ordinal) && otp == values.Otp);
}

public sealed class DevelopmentTokenService : ITokenService
{
    public Task<TokenIssue> IssueAsync(User user, Guid sessionId, CancellationToken cancellationToken)
    {
        var expires = DateTime.UtcNow.AddMinutes(15);
        return Task.FromResult(new TokenIssue($"dev.{user.UserId:D}.{sessionId:D}",
            Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32)),
            expires, Guid.NewGuid().ToString("N")));
    }
}

public interface IConfigurationValues
{
    string CaptchaId { get; }
    string CaptchaText { get; }
    string Otp { get; }
}

public sealed class ConfigurationValues(IConfiguration configuration) : IConfigurationValues
{
    public string CaptchaId => configuration["DevExternalApis:CaptchaId"]
        ?? throw new InvalidOperationException("DevExternalApis:CaptchaId is required in Development.");
    public string CaptchaText => configuration["DevExternalApis:CaptchaText"]
        ?? throw new InvalidOperationException("DevExternalApis:CaptchaText is required in Development.");
    public string Otp => configuration["DevExternalApis:Otp"]
        ?? throw new InvalidOperationException("DevExternalApis:Otp is required in Development.");
}

public sealed record CaptchaValidateRequest(
    [property: JsonPropertyName("captchaId")] string CaptchaId,
    [property: JsonPropertyName("captchaText")] string CaptchaText);
public sealed record CaptchaValidateResponse([property: JsonPropertyName("valid")] bool Valid);
public sealed record OtpSendApiRequest(
    [property: JsonPropertyName("destinationType")] string DestinationType,
    [property: JsonPropertyName("destinationValue")] string DestinationValue,
    [property: JsonPropertyName("purpose")] string Purpose);
public sealed record OtpSendApiResponse([property: JsonPropertyName("otpReferenceId")] string OtpReferenceId);
public sealed record OtpVerifyApiRequest(
    [property: JsonPropertyName("otpReferenceId")] string OtpReferenceId,
    [property: JsonPropertyName("otp")] string Otp);
public sealed record OtpVerifyApiResponse([property: JsonPropertyName("verified")] bool Verified);
public sealed record TokenUser(Guid UserId, string AgentCode, string FullName, string PrimaryEmail, string? IrdaLicenseNumber);
public sealed record TokenIssueApiRequest(TokenUser User, Guid SessionId);
public sealed record TokenIssueApiResponse(
    [property: JsonPropertyName("accessToken")] string AccessToken,
    [property: JsonPropertyName("refreshToken")] string RefreshToken,
    [property: JsonPropertyName("expiresUtc")] DateTime ExpiresUtc,
    [property: JsonPropertyName("tokenId")] string TokenId);
