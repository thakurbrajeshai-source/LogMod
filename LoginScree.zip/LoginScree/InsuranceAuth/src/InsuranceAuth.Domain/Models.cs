namespace InsuranceAuth.Domain;

public sealed record User(
    Guid UserId, string AgentCode, string? IrdaLicenseNumber, string FullName,
    string PrimaryEmail, string? AlternateEmail, string PrimaryMobile, string? AlternateMobile,
    string PasswordHash, DateTime PasswordChangedUtc, bool MustChangePassword,
    string PreferredLanguage, string Status, int FailedLoginCount, DateTime? LockoutEndUtc,
    DateTime? LastLoginUtc);

public sealed record ResetRequest(
    Guid ResetId, Guid UserId, string? DestinationType, string? OtpReferenceId, string Status,
    int OtpAttemptCount, int ResendCount, DateTime? LastSentUtc, DateTime? VerifiedUtc,
    byte[]? ResetTokenHash, DateTime? ResetTokenExpiresUtc, DateTime? UsedUtc,
    DateTime RequestedUtc, string? IpAddress);

public sealed record RegistrationRecord(
    Guid RegistrationId, Guid UserId, string AgentCode, string PrimaryMobile, string PrimaryEmail,
    string? MobileOtpReferenceId, string? EmailOtpReferenceId, bool MobileVerified, bool EmailVerified,
    int MobileOtpAttemptCount, int EmailOtpAttemptCount, string Status, DateTime ExpiresUtc,
    DateTime? MobileLastSentUtc, DateTime? EmailLastSentUtc);

public sealed record LoginFailureResult(int FailedLoginCount, bool IsLocked, DateTime? LockoutEndUtc);
public sealed record OtpFailureResult(int AttemptCount, bool IsFailed);
public sealed record PasswordHistoryEntry(string PasswordHash, DateTime CreatedUtc);
public sealed record UserSession(
    Guid SessionId, Guid UserId, string TokenId, string? IpAddress, string? UserAgent,
    string? DeviceInfo, DateTime ExpiresUtc);
public sealed record TokenIssue(string AccessToken, string RefreshToken, DateTime ExpiresUtc, string TokenId);
public sealed record AgentProfile(
    Guid UserId, string AgentCode, string? IrdaLicenseNumber, string FullName,
    string PrimaryEmail, string? AlternateEmail, string PrimaryMobile, string? AlternateMobile,
    string PreferredLanguage, string Status, bool MustChangePassword);

public enum ResultCode
{
    Ok, NotFound, LimitExceeded, Cooldown, InvalidState, InvalidToken, Locked, Inactive,
    Duplicate, OtpInvalid, AttemptsExceeded, Expired, AlreadyVerified, Completed, Unknown
}

public sealed class AuthException(string errorCode, string message, int statusCode, object? data = null)
    : Exception(message)
{
    public string ErrorCode { get; } = errorCode;
    public int StatusCode { get; } = statusCode;
    public object? AdditionalData { get; } = data;
}
